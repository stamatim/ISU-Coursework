package hw1;

/**
 * @author Stamatios Morellas (morellas@iastate.edu)
 */

/**
 * Status // DONE
 */

/**
 * A puma eats deers and competes against a jaguar.
 */
public class Puma extends Animal {
	/**
	 * Constructor
	 * @param j: jungle
	 * @param r: row position
	 * @param c: column position
	 * @param a: age
	 */
	public Puma (Jungle j, int r, int c, int a) {
		jungle = j;
		row = r;
		column = c;
		age = a;
	}

	/**
	 * A puma occupies the square.
	 */
	public State who() {
		return State.PUMA;
	}

	/**
	 * A puma dies of old age or hunger, or from attack by a jaguar.
	 * @param jNew jungle in the next cycle
	 * @return Living life form occupying the square in the next cycle.
	 */
	public Living next(Jungle jNew) {

		// Create a new integer array for the population
		int[] livingPop = new int[NUM_LIFE_FORMS];
		// Run the census method to count all life forms in 3x3 neighborhood
		census(livingPop);

		// If the puma is currently at age 4
		// The life form on a Puma square in the next cycle will be EMPTY
		if (age >= PUMA_MAX_AGE) {
			return new Empty(jNew, row, column);
		}

		// If there are more Jaguars than Pumas in the neighborhood
		// The life form on a Puma square in the next cycle will be JAGUAR
		else if (livingPop[JAGUAR] > livingPop[PUMA]) {
			return new Jaguar(jNew, row, column, 0);
		}

		// If Jaguars and Pumas together outnumber Deers in the neighborhood
		// The life form on a Puma square in the next cycle will be EMPTY
		else if ((livingPop[JAGUAR] + livingPop[PUMA]) > livingPop[DEER]) {
			return new Empty(jNew, row, column);
		}

		// If none of the other conditions are met
		// The Puma Lives on
		else {
			// Increment the age of the puma
			age++;
			return new Puma(jNew, row, column, age);
		}

	}
}
