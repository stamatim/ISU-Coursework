package hw1;

import static org.junit.Assert.assertEquals;

import java.io.FileNotFoundException;

import org.junit.Before;
import org.junit.Test;

public class GrassTest {

	protected Jungle jungle;

	@Before
	public void setUp() throws FileNotFoundException {
		jungle = new Jungle("3x3.txt");
	}

	@Test
	public void testWho() {
		State whoTestResult = jungle.grid[0][0].who();
		assertEquals(State.GRASS, whoTestResult);
	}

	@Test
	public void testNext() {
		String nextTestResult = jungle.grid[0][0].next(jungle).who().name();
		assertEquals(State.GRASS.name(), nextTestResult);
	}
}
