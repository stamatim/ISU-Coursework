package hw1;

/**
 * Status // DONE
 */

/**
 * Different forms of life.
 */
public enum State {
	DEER, EMPTY, GRASS, JAGUAR, PUMA
}
