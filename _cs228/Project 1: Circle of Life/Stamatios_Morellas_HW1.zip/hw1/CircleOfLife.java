package hw1;

import java.io.FileNotFoundException;
import java.util.Scanner;


/**
 * @author Stamatios Morellas (morellas@iastate.edu)
 */

/**
 * Status // DONE
 */

/**
 * The CircleOfLife class performs simulation over a grid jungle
 * with squares occupied by deers, jaguars, pumas, grass, or none.
 */
public class CircleOfLife {
	/**
	 * Update the new jungle from the old jungle in one cycle.
	 * @param jOld old jungle
	 * @param jNew new jungle
	 */
	public static void updateJungle(Jungle jOld, Jungle jNew) {

		// Step through the old jungle and update it to the new jungle.
		for (int i = 0; i < jOld.getWidth(); i++) { // Step through the rows of the old Jungle object
			for (int j = 0; j < jOld.getWidth(); j++) { // Step through the columns of the old Jungle object
				// Generates a living object in the new grid at the corresponding location
				// such that the former life form changes into the latter life form.
				// Employs the method "next()" from the Living class
				jNew.grid[i][j] = jOld.grid[i][j].next(jNew);
			}
		}
	}

	/**
	 * Repeatedly generates jungles either randomly or from reading files.
	 * Over each jungle, carries out an input number of cycles of evolution.
	 * @param args
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException {

		// The jungle after an even number of cycles
		Jungle even = new Jungle(0);
		// The jungle after an odd number of cycles
		Jungle odd = new Jungle(0);
		// Create a new scanner that reads from user input
		Scanner s = new Scanner(System.in);
		// The number of cycles of evolution from user input
		int numCycles = 0;
		// Create an initial Jungle
		Jungle jInit = new Jungle(0);
		// The value of the current key
		int currentKey = 0;
		// The key is valid unless the user input is any number besides 1, 2, or 3
		boolean validKey = true;
		// The width of the grid from the user input
		int currentWidth = 0;


		// Outputs the initial message to the console
		// Enter 1 to generate a random jungle, 2 to read a jungle from an input file,
		// and 3 to end the simulation. (An input file always ends with the suffix ".txt")
		System.out.println("Circle of Life in the Amazon Jungle \nkeys: 1 (random jungle)  2 (file input)  3 (exit)");

		while (validKey) {
			// Print the trial number to the console
			System.out.print("\nTrial: "); // "Trial: #"
			// Update the value of currentKey based on the user's input
			currentKey = s.nextInt();

			// Based on the number entered, the program will do 1 of 3 things
			switch (currentKey) {
				case 1: // Random jungle is chosen
					System.out.println("Random jungle");
					System.out.print("Enter grid width: "); // Ask the user to enter a width
					currentWidth = s.nextInt(); // Store the user-entered value for the width
					jInit = new Jungle(currentWidth); // Create a new jungle with the user-entered width
					// Generate the even and odd number jungles
					even = new Jungle(currentWidth);
					odd = new Jungle(currentWidth);
					jInit.randomInit(); // Initialize the jungle with randomly generated objects
					even =  jInit;
					odd = jInit;
					System.out.print("Enter the number of cycles: "); // Ask the user to enter a number of cycles
					numCycles = s.nextInt(); // Store the user-entered value for the number of cycles
					if (numCycles <= 0) {
						System.out.println("Error! Please enter a valid number of cycles. The number of cycles must be positive");
					}

					System.out.print("\n"); // Make a new line of output

					// Output the initial jungle
					System.out.println("Initial jungle: ");
					System.out.println(jInit);

					// Update the even and odd jungles alternatively based on the number of cycles
					for (int i = 0; i < numCycles; i++) {
						if (i % 2 == 0) { // If the cycle is even
							updateJungle(even, odd);
						}
						else { // If the cycle is odd
							updateJungle(odd, even);
						}
					}

					System.out.println("\nFinal jungle: "); // Display the final output of the jungle based on the number of cycles entered

					// If the number of cycles entered was even
					if (numCycles % 2 == 0) {
						System.out.println(even);
					}
					// If the number of cycles entered was odd
					else {
						System.out.println(odd);
					}

					// End the switch statement
					break;

				case 2: // File input is chosen
					System.out.println("Jungle input from a file");
					System.out.print("File name: "); // Prompt the user for the file name
					String filename = s.next(); // Store the name of the file as a string

					// Create a new jungle from the input filename
					jInit = new Jungle(filename);
					// Generate the even and odd number jungles
					even = new Jungle(filename);
					odd = new Jungle(filename);

					System.out.print("Enter the number of cycles: "); // Prompt the user for the number of cycles
					numCycles = s.nextInt(); // Update the value of the number of cycles
					if (numCycles <= 0) {
						System.out.println("Error! Please enter a valid number of cycles. The number of cycles must be positive");
					}

					System.out.print("\n"); // Enter a new line of output

					// Output the initial jungle
					System.out.println("Initial jungle: ");
					System.out.println(jInit);

					// Update the even and odd jungles alternatively based on the number of cycles
					for (int i = 0; i < numCycles; i++) {
						if (i % 2 == 0) { // If the cycle is even
							updateJungle(even, odd);
						}
						else { // If the cycle is odd
							updateJungle(odd, even);
						}
					}

					System.out.println("Final jungle: "); // Display the final output of the jungle based on the number of cycles entered

					// If the number of cycles entered was even
					if (numCycles % 2 == 0) {
						System.out.println(even);
					}
					// If the number of cycles entered was odd
					else {
						System.out.println(odd);
					}

					// End the switch statement
					break;

				case 3: // Exit is chosen
					// The key is no longer valid to run the program, so it ends
					validKey = false;
					// End the switch statement
					break;
			}
		}
		// Close the scanner when over
		s.close();
	}
}
