package hw1;

import static org.junit.Assert.assertEquals;

import java.io.FileNotFoundException;

import org.junit.Before;
import org.junit.Test;

/**
 * @author Stamatios Morellas (morellas@iastate.edu)
 */

public class CircleOfLifeTest {

	protected Jungle jungleOld;
	protected Jungle jungleNew;

	@Before
	public void setUp() throws FileNotFoundException {
		jungleOld = new Jungle("3x3.txt");
		jungleNew = new Jungle("1cycle.txt");
	}

	@Test
	public void testUpdateJungle() {
		assertEquals(jungleOld.grid[0][0].next(jungleNew).who().name(), jungleNew.grid[0][0].who().name());
		assertEquals(jungleOld.grid[0][1].next(jungleNew).who().name(), jungleNew.grid[0][1].who().name());
		assertEquals(jungleOld.grid[0][2].next(jungleNew).who().name(), jungleNew.grid[0][2].who().name());
		assertEquals(jungleOld.grid[1][0].next(jungleNew).who().name(), jungleNew.grid[1][0].who().name());
		assertEquals(jungleOld.grid[1][1].next(jungleNew).who().name(), jungleNew.grid[1][1].who().name());
		assertEquals(jungleOld.grid[1][2].next(jungleNew).who().name(), jungleNew.grid[1][2].who().name());
		assertEquals(jungleOld.grid[2][0].next(jungleNew).who().name(), jungleNew.grid[2][0].who().name());
		assertEquals(jungleOld.grid[2][1].next(jungleNew).who().name(), jungleNew.grid[2][1].who().name());
		assertEquals(jungleOld.grid[2][2].next(jungleNew).who().name(), jungleNew.grid[2][2].who().name());
	}
}
