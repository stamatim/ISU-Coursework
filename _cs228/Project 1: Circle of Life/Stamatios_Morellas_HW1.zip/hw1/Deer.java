package hw1;

/**
 * @author Stamatios Morellas (morellas@iastate.edu)
 */

/**
 * Status // DONE
 */

/*
 * A deer eats grass and lives no more than six years.
 */
public class Deer extends Animal {
	/**
	 * Creates a Deer object.
	 * @param j: jungle
	 * @param r: row position
	 * @param c: column position
	 * @param a: age
	 */
	public Deer (Jungle j, int r, int c, int a) {
		jungle = j;
		row = r;
		column = c;
		age = a;
	}

	// Deer occupies the square.
	public State who() {
		return State.DEER;
	}

	/**
	 * @param jNew jungle in the next cycle
	 * @return Living new life form occupying the same square
	 */
	public Living next(Jungle jNew) {

		// Create a new integer array for the population
		int[] livingPop = new int[NUM_LIFE_FORMS];
		// Run the census method to count all life forms in 3x3 neighborhood
		census(livingPop);

		// If the Deer's current age is 6
		// The life form on a Deer square in the next cycle will be EMPTY
		if (age >= DEER_MAX_AGE) {
			return new Empty(jNew, row, column);
		}

		// If there is no Grass in the neighborhood (the Deer needs food)
		// The life form on a Deer square in the next cycle will be EMPTY
		else if (livingPop[GRASS] == 0) {
			return new Empty(jNew, row, column);
		}

		// If in the neighborhood there are more Pumas and Jaguars together than Deers,
		// and furthermore, if there are at least twice as many Pumas as Jaguars
		// The life form on a Deer square in the next cycle will be PUMA
		else if (((livingPop[PUMA] + livingPop[JAGUAR]) > livingPop[DEER]) && (livingPop[JAGUAR] * 2 <= livingPop[PUMA])) {
			return new Puma(jNew, row, column, 0);
		}
		// If there are more Pumas and Jaquars together than Deers,
		// and if there are at least as many Jaguars as Pumas
		// The life form on a Deer square in the next cycle will be JAGUAR
		else if (((livingPop[PUMA] + livingPop[JAGUAR]) > livingPop[DEER]) && (livingPop[JAGUAR] >= livingPop[PUMA])) {
			return new Jaguar(jNew, row, column, 0);
		}

		// If none of the other conditions are met
		// The Deer Lives on
		else {
			// Increment the age of the deer
			age++;
			return new Deer(jNew, row, column, age);
		}
	}
}
