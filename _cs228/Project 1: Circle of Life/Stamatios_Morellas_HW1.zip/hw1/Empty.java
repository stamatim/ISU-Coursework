package hw1;

/**
 * @author Stamatios Morellas (morellas@iastate.edu)
 */

/**
 * Status // DONE
 */

/**
 * Empty squares are competed by various forms of life.
 */
public class Empty extends Living {
	public Empty (Jungle j, int r, int c) {
		jungle = j;
		row = r;
		column = c;
	}

	public State who() {
		return State.EMPTY;
	}

	/**
	 * An empty square will be occupied by a neighboring Deer, Grass, Jaguar, or Puma, or
	 * remain empty.
	 * @param jNew jungle in the next life cycle.
	 * @return Living life form in the next cycle.
	 */
	public Living next(Jungle jNew) {

		// Create a new integer array for the population
		int[] livingPop = new int[NUM_LIFE_FORMS];
		// Run the census method to count all life forms in 3x3 neighborhood
		census(livingPop);

		// If there is more than one neighboring Deer
		// The life form on an Empty square in the next cycle will be DEER
		if (livingPop[DEER] > 1) {
			return new Deer(jNew, row, column, 0);
		}

		// If there is more than one neighboring Puma
		// The life form on an Empty square in the next cycle will be PUMA
		else if (livingPop[PUMA] > 1) {
			return new Puma(jNew, row, column, 0);
		}

		// If there is more than one neighboring Jaguar
		// The life form on an Empty square in the next cycle will be JAGUAR
		else if (livingPop[JAGUAR] > 1) {
			return new Jaguar(jNew, row, column, 0);
		}

		// If there is at least one neighboring GRASS
		// The life form on an Empty square in the next cycle will be GRASS
		else if (livingPop[GRASS] >= 1) {
			return new Grass(jNew, row, column);
		}

		// If none of the other requirements are met
		// It is EMPTY
		else {
			return new Empty(jNew, row, column);
		}

	}
}
