package hw1;

/**
 * @author Stamatios Morellas (morellas@iastate.edu)
 */

/**
 * Status // DONE
 */

/**
 * A jaguar eats a deer and competes against a puma.
 */
public class Jaguar extends Animal {
	/**
	 * Constructor
	 * @param j: jungle
	 * @param r: row position
	 * @param c: column position
	 * @param a: age
	 */
	public Jaguar (Jungle j, int r, int c, int a) {
		jungle = j;
		row = r;
		column = c;
		age = a;
	}

	/**
	 * A jaguar occupies the square.
	 */
	public State who() {
		return State.JAGUAR;
	}

	/**
	 * A jaguar dies of old age or hunger, from isolation and attack by more numerous pumas.
	 * @param jNew jungle in the next cycle
	 * @return Living life form occupying the square in the next cycle.
	 */
	public Living next(Jungle jNew) {

		// Create a new integer array for the population
		int[] livingPop = new int[NUM_LIFE_FORMS];
		// Run the census method to count all life forms in 3x3 neighborhood
		census(livingPop);

		// If the Jaguar is at age 5 in the current cycle
		// The life form on a Jaguar square in the next cycle will be EMPTY
		if (age >= JAGUAR_MAX_AGE) {
			return new Empty(jNew, row, column);
		}

		// If there are at least twice as many Pumas as Jaguars in the neighborhood
		// The life form on a Jaguar square in the next cycle will be PUMA
		else if (livingPop[JAGUAR] * 2 <= livingPop[PUMA]) {
			return new Puma(jNew, row, column, 0);
		}

		// If Jaguars and Pumas together outnumber Deers in the neighborhood
		// The life form on a Jaguar square in the next cycle will be EMPTY
		else if ((livingPop[JAGUAR] + livingPop[PUMA]) > livingPop[DEER]) {
			return new Empty(jNew, row, column);
		}

		// If none of the other conditions are met
		// The Jaguar Lives on
		else {
			// Increment the age of the jaguar
			age++;
			return new Jaguar(jNew, row, column, age);
		}

	}
}
