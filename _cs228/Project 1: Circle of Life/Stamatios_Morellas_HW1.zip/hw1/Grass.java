package hw1;

/**
 * @author Stamatios Morellas (morellas@iastate.edu)
 */

/**
 * Status // DONE
 */

/**
 * Grass may be eaten out or taken over by deers.
 */
public class Grass extends Living
{
	public Grass (Jungle j, int r, int c)
	{
		jungle = j;
		row = r;
		column = c;
	}

	public State who() {
		return State.GRASS;
	}

	/**
	 * Grass can be eaten out by too many deers in the neighborhood. Deers may also
	 * multiply fast enough to take over Grass.
	 * @param jNew jungle in the next cycle
	 * @return Living  life form occupying the square in the next cycle.
	 */
	public Living next(Jungle jNew) {

		// Create a new integer array for the population
		int[] livingPop = new int[NUM_LIFE_FORMS];
		// Run the census method to count all life forms in 3x3 neighborhood
		census(livingPop);

		// If at least three times as many Deers as Grasses in the neighborhood
		// In the next cycle, the life form on a Grass square will be EMPTY
		if (livingPop[DEER] >= livingPop[GRASS] * 3) {
			return new Empty(jNew, row, column);
		}

		// If there are at least four Deers in the neighborhood
		// In the next cycle, the life form on a Grass square will be DEER
		else if (livingPop[DEER] >= 4) {
			return new Deer(jNew, row, column, 0);
		}

		// If none of the other conditions are met
		// It is GRASS
		else {
			return new Grass(jNew, row, column);
		}
	}
}
