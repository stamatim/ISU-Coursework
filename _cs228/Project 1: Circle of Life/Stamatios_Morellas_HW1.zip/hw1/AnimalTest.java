package hw1;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

/**
 * @author Stamatios Morellas (morellas@iastate.edu)
 */

/**
 * Test for Animal class
 */
public class AnimalTest {

	// Initialize a new jungle and deer object
	protected Jungle jungle;

	// Test the myAge method
	@Test
	public void testAge() {
		// Create the jungle with width 1
		jungle = new Jungle(1);
		// Create the deer object
		Deer d = new Deer(jungle, 0, 0, 0);
		// Get the age of the deer
		int age = d.myAge();
		// Test the scenario
		assertEquals(0, age);
	}
}
