package hw1;

/**
 * @author Stamatios Morellas (morellas@iastate.edu)
 */

/**
 * Status // DONE
 */

/**
 * To be implemented by the Animal class.
 */
public interface MyAge {
	int myAge(); // return age of the animal
}
