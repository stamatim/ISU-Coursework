package hw1;

import static org.junit.Assert.assertArrayEquals;

import java.io.FileNotFoundException;

import org.junit.Before;
import org.junit.Test;

public class LivingTest {

	protected Jungle jungle;
	protected int[] population;

	@Before
	public void setUp() throws FileNotFoundException {
		jungle = new Jungle("3x3.txt");
		population = new int[5];
	}

	@Test
	public void testCensus() {
		int[] expected = {2, 1, 2, 3, 1};
		jungle.grid[1][1].census(population);
		assertArrayEquals(population, expected);
	}
}
