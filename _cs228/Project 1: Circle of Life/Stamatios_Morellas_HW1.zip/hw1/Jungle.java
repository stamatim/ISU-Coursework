package hw1;

/**
 * @author Stamatios Morellas (morellas@iastate.edu)
 */

/**
 * Status // DONE
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.PrintWriter;
import java.util.Random;

/**
 * The jungle is represented as a square grid of size width X width.
 */
public class Jungle {
	private int width; // Grid size: width X width

	public Living[][] grid; // The current grid of Living objects

	/**
	 *  Default constructor reads from a file
	 */
	public Jungle(String inputFileName) throws FileNotFoundException {

		// Create a new file with the given filename
		File f = new File(inputFileName);
		// Create a new scanner to read the new file
		Scanner s = new Scanner(f);

		width = 0;
		// Create a temporary scanner to determine the width of the grid
		Scanner temp = new Scanner(f);
		while (temp.hasNextLine()) {
			temp.nextLine();
			width += 1;
		}
		// Close the temporary scanner
		temp.close();

		// Create the grid object with the given width, determined from the scanner
		grid = new Living[width][width];

		// Fill in the grid with objects according to the input file
		for (int i = 0; i < width; i++) { // Step through rows
			for (int j = 0; j < width; j++) { // Step through columns
				String current = s.next();

				// If the current animal is a Jaguar
				if (current.contains("J")) {
					// Get the age (at the first index)
					int age = current.charAt(1);
					// Add the Jaguar object to the grid
					// Remember to convert char to int
					grid[i][j] = new Jaguar(this, i, j, Character.getNumericValue(age));
				}

				// If the current animal is a Puma
				else if (current.contains("P")) {
					// Get the age
					int age = current.charAt(1);
					// Add the Puma object to the grid
					grid[i][j] = new Puma(this, i, j, Character.getNumericValue(age));
				}

				// If the current animal is a Deer
				else if (current.contains("D")) {
					// Get the age
					int age = current.charAt(1);
					// Add the Deer object to the grid
					grid[i][j] = new Deer(this, i, j, Character.getNumericValue(age));
				}

				// If the current animal is Grass
				else if (current.contains("G")) {
					// Add the Grass object to the grid
					grid[i][j] = new Grass(this, i, j);
				}

				// If the current animal is Empty
				else if (current.contains("E")) {
					// Add the Empty object to the grid
					grid[i][j] = new Empty(this, i, j);
				}
			}
		}

		// Close the scanner when finished
		s.close();
	}

	/**
	 * Constructor that builds a w X w grid without initializing it.
	 * @param width the grid
	 */
	public Jungle(int w) {
		width = w;
		grid = new Living[width][width];
	}

	/**
	 * Returns the current width
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * Initialize the jungle by randomly assigning to every square of the grid
	 * one of Deer, Empty, Grass, Jaguar, or Puma.
	 *
	 * Every animal starts at age 0.
	 */
	public void randomInit() {
		// Create a random number generator
		Random generator = new Random();
		// Identifies the current object as a Jaguar, Puma, Deer, Grass, or Empty based on the number
		int currentObject = 0;

		for (int i = 0; i < width; i++) { // Step through the rows of the grid
			for (int j = 0; j < width; j++) { // Steps through the columns of the grid
				// Generate a random object (number 0-4)
				currentObject = generator.nextInt(5);
				// Add the correct object to the grid
				switch (currentObject) {
					case 0: grid[i][j] = new Deer(this, i, j, 0); break;
					case 1: grid[i][j] = new Empty(this, i, j); break;
					case 2: grid[i][j] = new Grass(this, i, j); break;
					case 3: grid[i][j] = new Jaguar(this, i, j, 0); break;
					case 4: grid[i][j] = new Puma(this, i, j, 0); break;
				}
			}
		}
	}


	/**
	 * Output the jungle grid. For each square, output the first letter of the living form
	 * occupying the square. If the living form is an animal, then output the age of the animal
	 * followed by a blank space; otherwise, output two blanks.
	 */
	public String toString() {
		// Create a new string
		String newString = "";

		// Step through each "cell" in the grid
		for (int i = 0; i < grid.length; i++) { // Steps through the rows of the grid
			newString += "\n"; // Adds a new line (row) after the current grid row has been made
			for (int j = 0; j < grid[0].length; j++) { // Steps through the columns of the grid
				// The current object state
				State currentState = grid[i][j].who();
				// Add to the new string
				switch (currentState) {
					// Adds a J to the string followed by the Jaguar's age followed by a space
					case JAGUAR: newString += ("J" + ((Animal) grid[i][j]).myAge() + " "); break;
					// Adds a P to the string followed by the Puma's age followed by a space
					case PUMA: newString += ("P" + ((Animal) grid[i][j]).myAge() + " "); break;
					// Adds a D to the string followed by the Deer's age followed by a space
					case DEER: newString += ("D" + ((Animal) grid[i][j]).myAge() + " "); break;
					// Adds a G to the string followed by 2 blanks
					case GRASS: newString += "G  "; break;
					// Adds an E to the string followed by 2 blanks
					case EMPTY: newString += "E  "; break;
				}
			}
		}
		// Return the newly created string
		return newString;
	}


	/**
	 * Write the jungle grid to an output file.  Also useful for saving a randomly
	 * generated jungle for debugging purpose.
	 * @throws FileNotFoundException
	 */
	public void write(String outputFileName) throws FileNotFoundException {

		// Create a new file with the given filename
		File f = new File(outputFileName);
		// Open the file to output to with a PrintWriter
		PrintWriter p = new PrintWriter(f);
		// Create a new string
		String newString = "";
		// Gets the Jungle grid as a string by calling the toString() method from the Jungle class
		newString += this.toString();
		// Write to the file
		// The five life forms are represented by the characters D, E, G, J, and P
		p.print(newString);
		// Close the file
		p.close();
	}
}
