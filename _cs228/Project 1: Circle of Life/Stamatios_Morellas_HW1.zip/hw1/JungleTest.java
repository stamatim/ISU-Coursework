package hw1;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import org.junit.Before;
import org.junit.Test;

public class JungleTest {

	protected Jungle jungle;
	protected Jungle randJungle;
	
	@Before
	public void setUp() throws FileNotFoundException {
		jungle = new Jungle("3x3.txt");
		randJungle = new Jungle(3);
	}
	
	@Test
	public void testWidth() {
		int result = 3;
		assertEquals(jungle.getWidth(), result);
	}
	
	@Test
	public void testRandomInit() {
		randJungle.randomInit();
		
		for (int i = 0; i < randJungle.grid[0].length; i++) {
			for (int j = 0; j < randJungle.grid.length; j++) {
				State currentState = randJungle.grid[i][j].who();
				switch(currentState) {
					case DEER:
						assertEquals(State.DEER, currentState); break;
					case EMPTY:
						assertEquals(State.EMPTY, currentState); break;
					case GRASS:
						assertEquals(State.GRASS, currentState); break;
					case JAGUAR:
						assertEquals(State.JAGUAR, currentState); break;
					case PUMA:
						assertEquals(State.PUMA, currentState); break;
					default:
						System.out.println("Error! The random initializer is not working properly"); break;
				}
			}
		}
	}
	
	@Test
	public void testToString() throws FileNotFoundException {
		String result = jungle.toString();
		String newString = "";
		
		File f = new File("3x3.txt");
		Scanner s = new Scanner(f);
		
		while (s.hasNextLine()) {
			String currentLine = s.nextLine();
			newString = newString + "\n" + currentLine;
		}
		
		s.close();
		
		assertEquals(result, newString);
	}
	
}
