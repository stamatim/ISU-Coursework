package hw2;


import java.util.Comparator;


/**
 * An implementation of {@link Sorter} that performs merge sort
 * to sort the list.
 *
 * @author Stamatios Morellas - morellas@iastate.edu
 */
public class MergeSorter extends Sorter {
  @Override
  public void sort(WordList toSort, Comparator<String> comp) throws NullPointerException { 
    if (null == toSort || null == comp) {
      throw new NullPointerException();
    }
    mergeSortRec(toSort, comp, 0, toSort.length() - 1);
  }

  private void mergeSortRec(WordList list, Comparator<String> comp, int start, int end) {

    // Get the array of words from the given WordList
    String[] wordsArr = list.getArray();

    // The middle cutoff of the array
    int middle = (end - start) / 2;

    // The size for the first array
    int n1 = middle - start + 1;

    // The size for the second array
    int n2 = end - middle;

    // Create two temporary arrays with the given sizes
    String[] L = new String[n1];
    String[] R = new String[n2];

    // Copy the data into the two temporary arrays
    for (int i = 0; i < n1; i++) {
      L[i] = wordsArr[i + 1];
    }
    for (int i = 0; i < n2; i++) {
      R[i] = wordsArr[i + middle + 1];
    }

    // Merge the temporary arrays back into wordsArr[start...end]
    int subIdx1 = 0; // Initial index of the first sub array
    int subIdx2 = 0; // Initial index of the second sub array
    int subIdx3 = start; // Initial index of the merged sub array
    while (subIdx1 < n1 && subIdx2 < n2) {
      if (L[subIdx1].compareTo(R[subIdx2]) <= 0) {
        wordsArr[subIdx3] = L[subIdx1];
        subIdx1++;
      }
      else {
        wordsArr[subIdx3] = R[subIdx2];
        subIdx2++;
      }
      subIdx3++;
    }

    // Copy the remaining elements of L[]
    while (subIdx1 < n1) {
      wordsArr[subIdx3] = L[subIdx1];
      subIdx1++;
      subIdx3++;
    }

    // Copy the remaining elements of R[]
    while (subIdx2 < n2) {
      wordsArr[subIdx3] = R[subIdx2];
      subIdx2++;
      subIdx3++;
    }
  }
}
