package hw2;


import java.io.FileNotFoundException;
import java.util.Comparator;


/**
 * An class that compares various methods of sorting.
 *
 * @author Stamatios Morellas (morellas@iastate.edu)
 */
public class SorterFramework {
  /**
   * Loads data necessary to run the sorter statistics output, and runs it.
   * The only logic within this method should be that necessary to use the
   * given file names to create the {@link AlphabetComparator},
   * {@link WordList}, and sorters to use, and then using them to run the
   * sorter statistics output.
   *
   * @param args
   *   an array expected to contain two arguments:
   *    - the name of a file containing the ordering to use to compare
   *      characters
   *    - the name of a file containing words containing only characters in the
   *      other file
   */
  public static void main(String[] args) {
    try {
      // Create a new alphabet
      Alphabet a = new Alphabet(args[0]);
      // Create a new AlphabetComparator
      AlphabetComparator c = new AlphabetComparator(a);
      // Instantiate a new WordList
      WordList w;
      // Create the sorter array that holds each unique sorter type
      Sorter[] sort = new Sorter[3];
      // Add the sorters to the array
      sort[0] = new QuickSorter();
      sort[1] = new InsertionSorter();
      sort[2] = new MergeSorter();
      // Construct the WordList
      w = new WordList(args[1]);
      // Create a large number to construct the SorterFramework
      int num = 10000000;
      // Initialize the SorterFramework
      SorterFramework toRun = new SorterFramework(sort, c, w, num);
      // Run the SorterFramework
      toRun.run();
    }
    catch (NullPointerException e) {
      // Print the error to the console
      System.out.println("Error: Null Pointer");
      // Helps diagnose the exception
      e.printStackTrace();
    }
    catch (FileNotFoundException e) {
      // Print the error to the console
      System.out.println("Error: File Not Found");
      // Helps diagnose the exception
      e.printStackTrace();
    }
  }


  /**
   * The comparator to use for sorting.
   */
  private Comparator<String> comparator;

  /**
   * The words to sort.
   */
  private WordList words;

  /**
   * The array of sorters to use for sorting.
   */
  private Sorter[] sorters;

  /**
   * The total amount of words expected to be sorted by each sorter.
   */
  private int totalToSort;


  /**
   * Constructs and initializes the SorterFramework.
   *
   * @param sorters
   *   the array of sorters to use for sorting
   * @param comparator
   *   the comparator to use for sorting
   * @param words
   *   the words to sort
   * @param totalToSort
   *   the total amount of words expected to be sorted by each sorter
   * @throws NullPointerException
   *   if any of {@code sorters}, {@code comparator}, {@code words}, or
   *   elements of {@code sorters} are {@code null}
   * @throws IllegalArgumentException
   *   if {@code totalToSort} is negative
   */
  public SorterFramework(Sorter[] sorters, Comparator<String> comparator, WordList words, int totalToSort) throws NullPointerException, IllegalArgumentException { // DONE
    // Throw exception if any of the following have null code
    if (null == sorters || null == comparator || null == words) {
      throw new NullPointerException();
    }
    // Check the elements of the sorters array for null code
    for (int i = 0; i < sorters.length; i++) {
      if (null == sorters[i]) {
        throw new NullPointerException();
      }
    }
    // Check to see if totalToSort is negative
    if (totalToSort < 0) {
      throw new IllegalArgumentException();
    }

    // If everything else is good, construct accordingly
    this.sorters = sorters;
    this.comparator = comparator;
    this.words = words;
    this.totalToSort = totalToSort;
  }


  /**
   * Runs all sorters using
   * {@link Sorter#sortWithStatistics(WordList, Comparator, int)
   * sortWithStatistics()}, and then outputs the following information for each
   * sorter:
   *  - the name of the sorter
   *  - the length of the word list sorted each time
   *  - the total number of words sorted
   *  - the total time used to sort words
   *  - the average time to sort the word list
   *  - the number of elements sorted per second
   *  - the total number of comparisons performed
   */
  public void run() {
    // Step through the array of sorters and call the sortWithStatistics method
    // on each of them
    for (int i = 0; i < sorters.length; i++) {
      sorters[i].sortWithStatistics(words, comparator, totalToSort);
    }

    // Print the names of all the sorters
    System.out.print(String.format("%40s", "Sorters: "));
    for (int i = 0; i < sorters.length; i++) {
      System.out.print(String.format("%15s", sorters[i].getName()) + "\n");
    }

    // Print the length of the WordList sorted
    System.out.print(String.format("%40s", "WordList Length: "));
    for (int i = 0; i < sorters.length; i++) {
      System.out.print(String.format("%15d", words.length()) + "\n");
    }

    // Print the total number of words that have been sorted
    System.out.print(String.format("%40s", "Total Words Sorted: "));
    for (int i = 0; i < sorters.length; i++) {
      System.out.print(String.format("%15d", sorters[i].getTotalWordsSorted()) + "\n");
    }

    // Print the total time used to sort words
    System.out.print(String.format("%40s", "Total Time To Sort Words: "));
    for (int i = 0; i < sorters.length; i++) {
      System.out.print(String.format("%15d", sorters[i].getTotalSortingTime()) + "\n");
    }

    // Print the average time used to sort the WordList
    System.out.print(String.format("%40s", "Average Time To Sort The WordList: "));
    for (int i = 0; i < sorters.length; i++) {
      System.out.print(String.format("%15d", sorters[i].getTotalSortingTime() * (long) (words.length() / sorters[i].getTotalWordsSorted())) + "\n");
    }

    // Print the number of elements sorted per second
    System.out.print(String.format("%40s", "Number Of Elements Sorted Per Second: "));
    for (int i = 0; i < sorters.length; i++) {
      System.out.print(String.format("%15f", sorters[i].getTotalWordsSorted() * 1000 / (((double) sorters[i].getTotalSortingTime()) / 1000.0) + "\n"));
    }

    // Print the total number of comparisons performed
    System.out.print(String.format("%40s", "Total Number Of Comparisons Performed: "));
    for (int i = 0; i < sorters.length; i++) {
      System.out.print(String.format("%15d", sorters[i].getTotalComparisons()));
    }
  }
}
