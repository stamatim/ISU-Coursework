package hw2;


import java.util.Comparator;


/**
 * An implementation of {@link Sorter} that performs insertion sort
 * to sort the list.
 *
 * @author Stamatios Morellas – morellas@iastate.edu
 */
public class InsertionSorter extends Sorter {
  @Override
  public void sort(WordList toSort, Comparator<String> comp) throws NullPointerException {
    // The size of the given WordList
    int listLength = toSort.length();
    // Create a variable for the array
    String[] arr = toSort.getArray();
    // Step through the array and swaps the proper elements
    for (int i = 1; i < listLength; i++) {
      // Create a temporary var for the current array element
      String temp = arr[i];
      // Create a variable to hold the previous index from the current one
      int j = i - 1;
      // While the previous index is at least 0 AND the current String in
      // the array comes before the previous
      while (j > -1 && temp.compareTo(arr[j]) < 0) {
        // The current String is replaced with the previous until j reaches 0
        arr[j + 1] = arr[j];
        j--;
      }
      // Performs the swap
      arr[j + 1] = temp;
    }
  }
}
