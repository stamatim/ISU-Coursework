package hw2;


import java.util.Comparator;


/**
 * A string comparator that uses an ordering of an {@link Alphabet} to
 * determine how to compare individual characters.
 *
 * @author Stamatios Morellas – morellas@iastate.edu
 */
public class AlphabetComparator implements Comparator<String> {
  /**
   * The ordering used to compare characters.
   */
  private Alphabet alphabet;

  /**
   * Constructs and initializes the comparator to use the given ordering.
   *
   * @param ordering
   *   the ordering to use to compare characters
   * @throws NullPointerException
   *   if {@code ordering} is {@code null}
   */
  public AlphabetComparator(Alphabet ordering) throws NullPointerException {
    alphabet = ordering;
  }

  /**
   * Compares the two given strings based on the ordering used by this
   * comparator.
   *
   * Returns a negative value if the first string is considered less than the
   * second, a positive value if greater than the second, and zero if the two
   * strings are equal. Note that an exception must be thrown if the strings
   * contain invalid characters, even if the two strings are equal.
   *
   * For each character of the given strings, the ordering is consulted to
   * determine which of the two characters should go first, with the one with a
   * lesser position in the ordering being determined to be lesser. If the
   * position of the characters are the same, the next character is examined.
   * After the end of one of the strings is reached, the shorter string is
   * considered to be lesser than the other.
   *
   * @throws NullPointerException
   *   if either of {@code a} or {@code b} are {@code null}
   * @throws IllegalArgumentException
   *   if either of {@code a} or {@code b} contain a character not found in
   *   this comparator's ordering
   */
  @Override
  public int compare(String a, String b) throws NullPointerException, IllegalArgumentException {

    // If either of the Strings are null code, throw a NullPointerException
    if (null == a || null == b) {
      throw new NullPointerException();
    }

    // If either of the Strings contain a character not found in the ordering, throw an IllegalArgumentException
    // Check the First String
    for (int i = 0; i < a.length(); i++) {
      boolean valid = alphabet.isValid(a.charAt(i));

      if (!valid) {
        throw new IllegalArgumentException();
      }
    }
    // Check the Second String
    for (int i = 0; i < b.length(); i++) {
      boolean valid = alphabet.isValid(b.charAt(i));

      if (!valid) {
        throw new IllegalArgumentException();
      }
    }

    // The index that is being compared from the two strings
    int index = 0;

    // The result that will be returned from this method
    int result = 0;

    // While the char index being compared is within the bounds of the strings
    while (index < a.length() && index < b.length()) {
        if (alphabet.getPosition(a.charAt(index)) == alphabet.getPosition(b.charAt(index))) {
          result = 0;
        }
        if (alphabet.getPosition(a.charAt(index)) < alphabet.getPosition(b.charAt(index))) {
          result = -1;
        }
        if (alphabet.getPosition(a.charAt(index)) > alphabet.getPosition(b.charAt(index))) {
          result = 1;
        }
        // Update the current index
        index++;
    }
    return result;
  }
}
