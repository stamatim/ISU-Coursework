package hw2;

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.File;
import java.lang.String;

/**
 * A class representing an ordering of characters that can be queried to know
 * the position of a given character.
 *
 * @author Stamatios Morellas - morellas@iastate.edu
 */
public class Alphabet {

  /**
   * A lookup table containing characters and their positions.
   * Sorted by the character of each entry.
   */
  private CharAndPos[] lookup;

  /**
   * Constructs and initializes the ordering to have exactly the ordering of
   * the elements in the given array.
   *
   * @param ordering
   *   the array containing the characters, in the ordering desired
   * @throws NullPointerException
   *   if {@code ordering} is {@code null}
   */
  public Alphabet(char[] ordering) throws NullPointerException {
    // Initialize the CharAndPos array to have the length of the ordering
    lookup = new CharAndPos[ordering.length];
  }

  /**
   * Constructs and initializes the ordering by reading from the indicated
   * file. The file is expected to have a single character on each line, and
   * the ordering in the file is the order that will be used.
   *
   * @param filename
   *   the name of the file to read
   * @throws NullPointerException
   *   if {@code filename} is {@code null}
   * @throws FileNotFoundException
   *   if the file cannot be found
   */
  public Alphabet(String filename) throws NullPointerException, FileNotFoundException {
    // Create a new File with the given filename
    File file = new File(filename);
    // Create a new Scanner to read from the file
    Scanner s = new Scanner(file);
    // The number of letters that are in the ordering
    int elementCount = 0;

    // First, look through the file to see how many elements are in the ordering

    // While the scanner still has another line of input
    while (s.hasNextLine()) {
      elementCount++;
    }

    // Now that the count has been updated, create a lookup array
    // with the correct number of spaces

    lookup = new CharAndPos[elementCount];
    int lookupIndex = 0;

    // While the scanner has another line of input
    while (s.hasNextLine()) {
      // The current line in the ordering in string form
      String currentString = s.nextLine();
      // The current character from the line
      char currentChar = currentString.charAt(0);
      // True if the current character is a space
      boolean space = false;

      // If the current character is a space
      if(currentString.isEmpty()) {
        lookup[lookupIndex] = new CharAndPos(' ', lookupIndex);
        space = true;
      }
      // Otherwise, update the current character normally
      else {
        currentChar = currentString.charAt(lookupIndex);
      }
      // If there wasn't a space
      if (!space) {
        // Update the lookup array
        lookup[lookupIndex] = new CharAndPos(currentChar, lookupIndex);
      }
      // Update the lookup index and the space status
      lookupIndex++;
    }
    // Close the Scanner when finished
    s.close();
  }

  /**
   * Returns true if and only if the given character is present in the
   * ordering.
   *
   * @param c
   *   the character to test
   * @return
   *   true if and only if the given character is present in the ordering
   */
  public boolean isValid(char c) {
    // Assume the character is not valid
    boolean result = false;
    // Step through the char array
    for (int i = 0; i < lookup.length; i++) {
      // If the character is contained in the array
      if (lookup[i].character == c) {
        // Then the character is valid
        return true;
      }
      // If the character is not contained in the array
      else {
        // Then the character remains invalid
        result = false;
      }
    }
    // Return the result
    return result;
  }

  /**
   * Returns the position of the given character in the ordering.
   * Returns a negative value if the given character is not present in the
   * ordering.
   *
   * @param c
   *   the character of which the position will be determined
   * @return
   *   the position of the given character, or a negative value if the given
   *   character is not present in the ordering
   */
  public int getPosition(char c) {
    // Step through the ordering array to find the position of the char
    for (int i = 0; i < lookup.length; i++) {
      // Create a variable for the current position
      int currentChar = lookup[i].character;
      // If the current character is the one being searched for
      if (currentChar == c) {
        // Return the position of that character
        return i;
      }
    }
    // If the position of the given character is not present in the ordering
    // return a negative value
    return -1;
  }

  /**
   * Returns the index of the entry containing the given character within the
   * lookup table {@link #lookup}.
   * Returns a negative value if the given character does not have an entry in
   * the table.
   *
   * @param toFind
   *   the character for which to search
   * @return
   *   the index of the entry containing the given character, or a negative
   *   value if the given character does not have an entry in the table
   */
  private int binarySearch(char toFind) {
    // The current character being analyzed
    char currentChar = ' ';
    // Step through the char array to try to find a match
    for (int i = 0; i < lookup.length; i++) {
      // Update the current character being analyzed
      currentChar = lookup[i].character;
      // If the current char matches the desired char being searched for
      if (currentChar == toFind) {
        // Then return the current index of the matching char
        return i;
      }
    }
    // If the given character does not have a entry in the table
    // return a negative value
    return -1;
  }


  /**
   * A PODT class containing a character and a position.
   * Used as the entry type within {@link Alphabet#lookup lookup}.
   */
  /* already completed */
  private static class CharAndPos {
    /**
     * The character of the entry.
     */
    public char character;

    /**
     * The position of the entry in the ordering.
     */
    public int position;


    /**
     * Constructs and initializes the entry with the given values.
     *
     * @param character
     *   the character of the entry
     * @param position
     *   the position of the entry
     */
    public CharAndPos(char character, int position) {
      this.character = character;
      this.position = position;
    }


    @Override
    public boolean equals(Object obj) {
      if (null == obj || this.getClass() != obj.getClass()) {
        return false;
      }

      CharAndPos o = (CharAndPos) obj;

      return this.character == o.character && this.position == o.position;
    }

    @Override
    public int hashCode() {
      return character ^ position;
    }

    @Override
    public String toString() {
      return "{" + character + ", " + position + "}";
    }
  }
}
