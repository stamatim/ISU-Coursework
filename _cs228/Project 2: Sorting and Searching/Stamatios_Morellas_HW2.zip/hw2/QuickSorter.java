package hw2;


import java.util.Comparator;


/**
 * An implementation of {@link Sorter} that performs quick sort
 * to sort the list.
 *
 * @author Stamatios Morellas – morellas@iastate.edu
 */
public class QuickSorter extends Sorter {
  @Override
  public void sort(WordList toSort, Comparator<String> comp) throws NullPointerException {
    if (null == toSort || null == comp) {
      throw new NullPointerException();
    }
    quickSortRec(toSort, comp, 0, toSort.length() - 1);
  }

  private void quickSortRec(WordList list, Comparator<String> comp, int start, int end) { 
    if (start >= end) {
      return;
    }
    int p = partition(list, comp, start, end);
    quickSortRec(list, comp, start, p - 1);
    quickSortRec(list, comp, p + 1, end);
  }

  private int partition(WordList list, Comparator<String> comp, int start, int end) {
    // Use the last element as the pivot point
    String pivot = list.get(end);
    // The previous index (smaller element)
    int i = start - 1;
    // Step through the list
    for (int j = start; j <= end - 1; j++) { // ???
      // If the current element is less than or equal to the pivot
      if (list.get(j).compareTo(pivot) <= 0) {
        // Increment the index of the smaller element
        i++;
        // Swap the two elements
        list.swap(i, j);
      }
    }
    list.swap(i + 1, end);
    return i + 1;
  }
}
