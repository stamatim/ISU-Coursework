package hw4;

/**
 *
 * @author Stamatios Morellas (morellas@iastate.edu)
 *
 */

/**
 *
 * This class executes two convex hull algorithms: Graham's scan and Jarvis' march, over randomly
 * generated integers as well integers from a file input. It compares the execution times of
 * these algorithms on the same input.
 *
 */
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Random;


public class CompareHullAlgorithms { // DONE
	/**
	 * Repeatedly take points either randomly generated or read from files. Perform Graham's scan and
	 * Jarvis' march over the input set of points, comparing their performances.
	 *
	 * @param args
	 */
	public static void main(String[] args) { // DONE
		ConvexHull[] algorithms = new ConvexHull[2]; // The algorithms that are used (GrahamScan or JarvisMarch)
		Random r = new Random(); // A random number generator
		Scanner s = new Scanner(System.in); // A scanner that reads user input


		System.out.println("Comparison Between Convex Hull Algorithms");
		System.out.print("Choose a trial:	[1] or [2] or [3]\n");
		int trialInput = s.nextInt();

		// 1. Generate random points
		if (trialInput == 1) {
			System.out.print("Enter a number of random points: ");
			int numPointsInput = s.nextInt();
			System.out.print("\n"); // Next line

			// Construct and draw the hull with the given points
			algorithms[0] = new GrahamScan(generateRandomPoints(numPointsInput, r));
			algorithms[1] = new JarvisMarch(generateRandomPoints(numPointsInput, r));
			algorithms[0].time = System.nanoTime();
			algorithms[1].time = System.nanoTime();
			algorithms[0].constructHull();
			algorithms[1].constructHull();
			algorithms[0].time = System.nanoTime();
			algorithms[1].time = System.nanoTime();
			algorithms[0].draw();
			algorithms[1].draw();

			// Print statistics table
			System.out.println("algorithm        size        time (ns)");
			System.out.println("--------------------------------------");
			System.out.println(algorithms[0].stats());
			System.out.println(algorithms[1].stats());
			System.out.println("--------------------------------------");
		}
		// 2. User inputs a file
		if (trialInput == 2) {
			System.out.println("Points from a file");
			System.out.print("Enter a filename: ");
			String filenameInput = s.next();
			System.out.print("\n"); // Next line

			try {

				// Construct and draw the hull with the points from the input file
				algorithms[0] = new GrahamScan(filenameInput);
				algorithms[1] = new JarvisMarch(filenameInput);
				algorithms[0].time = System.nanoTime();
				algorithms[1].time = System.nanoTime();
				algorithms[0].constructHull();
				algorithms[1].constructHull();
				algorithms[0].time = System.nanoTime();
				algorithms[1].time = System.nanoTime();
				algorithms[0].draw();
				algorithms[1].draw();

				// Print the statistics table
				System.out.println("algorithm        size        time (ns)");
				System.out.println("--------------------------------------");
				System.out.println(algorithms[0].stats());
				System.out.println(algorithms[1].stats());
				System.out.println("--------------------------------------");
				
			}
			catch (FileNotFoundException e) {
				System.out.println("Error: File Not Found");
			}
		}
		// 3. Terminates the program
		if (trialInput == 3) {
			System.out.println("[Program Terminated]");
			System.exit(0);
			
		}

		// Close the scanner
		s.close();
	}

	/**
	 * This method generates a given number of random points.  The coordinates of these points are
	 * pseudo-random numbers within the range [-50,50] � [-50,50].
	 *
	 * @param numPts  	number of points
	 * @param rand      Random object to allow seeding of the random number generator
	 * @throws IllegalArgumentException if numPts < 1
	 */
	private static Point[] generateRandomPoints(int numPts, Random rand) throws IllegalArgumentException { // DONE
		// 1. Initialize the needed variables
		rand = new Random(); // Initialize the random object
		// int randNum = rand.nextInt(101) - 50; // A random number from [-50, 50]
		int n = 0; // The point counter
		Point[] arr = new Point[numPts]; // The point array to be returned

		// 2. Check for the exception
		if (numPts < 1) {
			throw new IllegalArgumentException();
		}

		// 3. Fill the array to be returned
		while (n < numPts) { // While the desired number of random points created hasn't been met
			arr[n] = new Point(rand.nextInt(101) - 50, rand.nextInt(101) - 50); // Create a new point with random x and y coordinates from [-50, 50]
			n++; // Increment the number of points that have been created
		}

		// 4. Return the array
		return arr;
	}
}
