package hw4;

import java.util.Comparator;

/**
 * This class sorts an array of Point objects using a provided Comparator.  For the purpose
 * you may adapt your implementation of quicksort from Project 2.
 */
public class QuickSortPoints { // DONE
	private Point[] points; // Array of points to be sorted.

	/**
	 * Constructor takes an array of Point objects.
	 *
	 * @param pts
	 */
	QuickSortPoints(Point[] pts) { // DONE
		this.points = pts;
	}

	/**
	 * Copy the sorted array to pts[].
	 *
	 * @param pts array to copy onto
	 */
	void getSortedPoints(Point[] pts) { // DONE
		for (int i = 0; i < pts.length; i++) {
			pts[i] = points[i];
		}
	}


	/**
	 * Perform quicksort on the array points[] with a supplied comparator.
	 *
	 * @param comp
	 */
	public void quickSort(Comparator<Point> comp) { // DONE
		quickSortRec(0, points.length - 1, comp);
	}


	/**
	 * Operates on the subarray of points[] with indices between first and last.
	 *
	 * @param first  starting index of the subarray
	 * @param last   ending index of the subarray
	 */
	private void quickSortRec(int first, int last, Comparator<Point> comp) { // DONE
		if (first < last) {
			// Create the partition and perform the quick sort
			int p = partition(first, last, comp);
			quickSortRec(first, p - 1, comp);
			quickSortRec(p + 1, last, comp);
		}
	}

	/**
	 * Operates on the subarray of points[] with indices between first and last.
	 *
	 * @param first
	 * @param last
	 * @return
	 */
	private int partition(int first, int last, Comparator<Point> comp) { // TODO
		// Use last element in the points array as the pivot point
		Point pivot = points[last];
		// The previous index (smaller element)
		int i = first - 1;
		// Step through the list
		for (int j = first; j < last; j++) {
			// If the current element is less than or equal to the pivot
			if (comp.compare(points[j], pivot) < 0) {
				// Increment the index of the smaller element
				i++;
				// Swap the two elements
				Point temp = new Point(points[i]);
				points[i] = new Point(points[j]);
				points[j] = temp;
			}
		}
		Point temp = new Point(points[i + 1]);
		points[i + 1] = new Point(points[last]);
		points[last] = temp;
		return i + 1;
	}
}
