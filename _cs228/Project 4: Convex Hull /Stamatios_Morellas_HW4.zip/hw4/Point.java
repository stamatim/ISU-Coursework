package hw4;

/**
 *
 * @author Stamatios Morellas (morellas@iastate.edu)
 *
 */

public class Point implements Comparable<Point> { // DONE
	private int x;
	private int y;

	public Point() { // default constructor // DONE
				 	// x and y get default value 0
		x = 0;
		y = 0;
	}

	public Point(int x, int y) { // DONE
		this.x = x;
		this.y = y;
	}

	public Point(Point p) { // copy constructor // DONE
		x = p.getX();
		y = p.getY();
	}

	public int getX() { // DONE
		return x;
	}

	public int getY() { // DONE
		return y;
	}

	@Override
	public boolean equals(Object obj) { // DONE
		if (obj == null || obj.getClass() != this.getClass()) {
			return false;
		}

		Point other = (Point) obj;

		return x == other.x && y == other.y;
	}

	/**
	 * Compare this point with a second point q in the bottom-up order.
	 *
	 * IMPORTANT: Compare y-coordinates first, and in case of a tie, compare x-coordinates.
	 *
	 * @param q
	 * @return  -1  if this.y < q.y || (this.y == q.y && this.x < q.x)
	 * 		    0   if this.y == q.y && this.x == q.x
	 * 			1	otherwise
	 */
	public int compareTo(Point q) { // DONE
		// If this.y < q.y || (this.y == q.y && this.x < q.x)
		if (this.y < q.y || (this.y == q.y && this.x < q.x)) {
			// Return -1
			return -1;
		}
		// If this.y == q.y && this.x == q.x
		else if (this.y == q.y && this.x == q.x) {
			// Return 0
			return 0;
		}
		// Otherwise
		else {
			// Return 1
			return 1;
		}
	}

	/**
	 * Output a point in the standard form (x, y).
	 */
	@Override
	public String toString() { // DONE
		// Output a point in the form (x, y)
		return "(" + this.x + ", " + this.y + ")";
	}
}
