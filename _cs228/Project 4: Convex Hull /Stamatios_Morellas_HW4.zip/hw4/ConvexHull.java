package hw4;

/**
 *
 * @author Stamatios Morellas (morellas@iastate.edu)
 *
 */


import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * This class implements construction of the convex hull of a finite number of points.
 *
 */

public abstract class ConvexHull {

	// ---------------
	// Data Structures
	// ---------------

	protected String algorithm;  // Its value is either "Graham's scan" or "Jarvis' march".
	                             // Initialized by a subclass.

	protected long time;         // execution time in nanoseconds

	/**
	 * The array points[] holds an input set of Points, which may be randomly generated or
	 * input from a file.  Duplicates are possible.
	 */
	private Point[] points;


	/**
	 * Lowest point from points[]; and in case of a tie, the leftmost one of all such points.
	 * To be set by a constructor.
	 */
	protected Point lowestPoint;


	/**
	 * This array stores the same set of points from points[] with all duplicates removed.
	 * These are the points on which Graham's scan and Jarvis' march will be performed.
	 */
	protected Point[] pointsNoDuplicate;


	/**
	 * Vertices of the convex hull in counterclockwise order are stored in the array
	 * hullVertices[], with hullVertices[0] storing lowestPoint.
	 */
	protected Point[] hullVertices;


	protected QuickSortPoints quicksorter;  // used (and reset) by this class and its subclass GrahamScan

	// ------------
	// Constructors
	// ------------

	/**
	 * Constructor over an array of points.
	 *
	 *    1) Store the points in the private array points[].
	 *
	 *    2) Initialize quick sorter.
	 *
	 *    3) Call removeDuplicates() to store distinct points from the input in pointsNoDuplicate[].
	 *
	 *    4) Set lowestPoint to pointsNoDuplicate[0].
	 *
	 * @param pts
	 * @throws IllegalArgumentException if pts.length == 0
	 */
	public ConvexHull(Point[] pts) throws IllegalArgumentException { // DONE
		// If pts.length == 0, throw exception
		if (pts.length == 0) {
			throw new IllegalArgumentException();
		}
		points = new Point[pts.length];
		// 1. Store the points in the private array points[]
		for (int i = 0; i < pts.length; i++) {
			points[i] = new Point(pts[i].getX(), pts[i].getY());
		}

		// 2. Initialize quick sorter
		quicksorter = new QuickSortPoints(points);

		// 3. Call removeDuplicates() to store distinct points from the input in pointsNoDuplicate[]
		this.removeDuplicates();

		// 4. Set lowestPoint to pointsNoDuplicate[0]
		lowestPoint = pointsNoDuplicate[0];
	}

	/**
	 * Read integers from an input file. Every pair of integers represent the x- and y-coordinates
	 * of a point. Generate the points and store them in the private array points[]. The total
	 * number of integers in the file must be even.
	 *
	 * You may declare a Scanner object and call its methods such as hasNext(), hasNextInt()
	 * and nextInt(). An ArrayList may be used to store the input integers as they are read in
	 * from the file.
	 *
	 * Perform the operations 1 - 4 described for the previous constructor.
	 *
	 * @param  inputFileName
	 * @throws FileNotFoundException
	 * @throws InputMismatchException when the input file contains an odd number of integers
	 */
	public ConvexHull(String inputFileName) throws FileNotFoundException, InputMismatchException { // DONE
		// Throw an exception if the file cannot be found
		if (inputFileName == null) {
			throw new FileNotFoundException();
		}

		// Create a new file with the given filename
		File f = new File(inputFileName);
		// Create a temporaty Scanner to count the number integers in the file
		Scanner temp = new Scanner(f);
		// The number of integers in the input file
		int numIntegersInFile = 0;

		// Make sure the input file has an even number of integers
		while (temp.hasNextLine()) { // While there is a next line
			while (temp.hasNextInt()) { // While there's another integer in the line
				numIntegersInFile++; // Increment the number of integers in the file
			}
		}

		// Close the temporary Scanner
		temp.close();

		// If the number of integers in the file is not even
		if (numIntegersInFile % 2 != 0) {
			throw new InputMismatchException();
		}

		// Create a new Scanner to create the points
		Scanner s = new Scanner(f);
		// Initialize the point array to be the correct size
		points = new Point[numIntegersInFile / 2];
		// Current index of the point array
		int i = 0;

		// 1. Store the points in the private array points[]
		while (s.hasNextLine()) { // While the scanner has a next line
			while (s.hasNextInt()) { // While there is another integer on the line
				int x = s.nextInt(); // Store the next integer as x
				int y = s.nextInt(); // Store the next integer after x as y
				points[i] = new Point(x, y); // Add the points to the point array
				i++; // Increment the index of the points array after the point has been added
			}
		}

		// Close the main scanner
		s.close();

		// 2. Initialize quicksorter with the given points
		quicksorter = new QuickSortPoints(points);

		// 3. Call removeDuplicates() to store distinct points from the input in pointsNoDuplicate[]
		this.removeDuplicates();

		// 4. Set lowestPoint to pointsNoDuplicate[0]
		lowestPoint = pointsNoDuplicate[0];
	}

	/**
	 * Construct the convex hull of the points in the array pointsNoDuplicate[].
	 */
	public abstract void constructHull(); // Implement in child classes

	/**
	 * Outputs performance statistics in the format:
	 *
	 * <convex hull algorithm> <size>  <time>
	 *
	 * For instance,
	 *
	 * Graham's scan   1000	  9200867
	 *
	 * Use the spacing in the sample run in Section 5 of the project description.
	 */
	public String stats() { // DONE
		// Return performance statistics in proper format
		return this.algorithm + "    " + this.points.length + "          " + this.time;
	}

	/**
	 * The string displays the convex hull with vertices in counterclockwise order starting at
	 * lowestPoint.  When printed out, it will list five points per line with three blanks in
	 * between. Every point appears in the format "(x, y)".
	 *
	 * For illustration, the convex hull example in the project description will have its
	 * toString() generate the output below:
	 *
	 * (-7, -10)   (0, -10)   (10, 5)   (0, 8)   (-10, 0)
	 *
	 * lowestPoint is listed only ONCE.
	 *
	 * Called only after constructHull().
	 */
	public String toString() { // DONE
		// Create a string to be returned
		String result = "";
		// Step through the hullVertices array
		for (int i = 0; i < hullVertices.length; i++) {
			// Add to the result string in the proper format
			result += "(" + hullVertices[i].getX() + ", " + hullVertices[i].getY() + ")   ";
		}
		// Return the new string
		return result;
	}

	/**
	 *
	 * Writes to the file "hull.txt" the vertices of the constructed convex hull in counterclockwise
	 * order. These vertices are in the array hullVertices[], starting with lowestPoint. Every line
	 * in the file displays the x and y coordinates of only one point.
	 *
	 * For instance, the file "hull.txt" generated for the convex hull example in the project
	 * description will have the following content:
	 *
	 *  -7 -10
	 *  0 -10
	 *  10 5
	 *  0  8
	 *  -10 0
	 *
	 * The generated file is useful for debugging as well as grading.
	 *
	 * Called only after constructHull().
	 *
	 *
	 * @throws IllegalStateException  if hullVertices[] has not been populated (i.e., the convex
	 *                                   hull has not been constructed)
	 */
	public void writeHullToFile() throws IllegalStateException { // CHECK AGAIN

		// If hullVertices[] has not been populated, throw an exception
		if (hullVertices[0] == null) {
			throw new IllegalStateException();
		}

		// Create a new file named "hull.txt"
		File f = new File("hull.txt");
		// Declare the PrintWriter
		PrintWriter p = null;

		// Do this normally
		try {
			// Instantiate the PrintWriter
			p = new PrintWriter(f);

			// Iterate through the hullVertices array
			for (int i = 0; i < hullVertices.length; i++) {
				// Print the vertices for each point in the hullVertices array on a new line
				p.println(hullVertices[i].getX() + " " + hullVertices[i].getY());
			}
		}

		// Catch the exception
		catch (FileNotFoundException e) {
			// Report the exception
		}

		// Close the PrintWriter
		p.close();
	}

	/**
	 * Draw the points and their convex hull. This method is called after construction of the
	 * convex hull. You just need to make use of hullVertices[] to generate a list of segments
	 * as the edges. Then create a Plot object to call the method myFrame().
	 */
	public void draw() { // DONE

		int numSegs = hullVertices.length;  // number of segments to draw

		// Based on Section 4, generate the line segments to draw for display of the convex hull.
		// Assign their number to numSegs, and store them in segments[] in the order.
		Segment[] segments = new Segment[numSegs];

		// Create a pannel
		// Fill the segments array (except the last one)
		for (int i = 0; i < numSegs - 1; i++) {
			segments[i] = new Segment(hullVertices[i], hullVertices[i + 1]);
		}
		
		// Add the last segment
		segments[numSegs - 1] = new Segment(hullVertices[hullVertices.length - 1], hullVertices[0]);
		
		// The following statement creates a window to display the convex hull.
		Plot.myFrame(pointsNoDuplicate, segments, getClass().getName());
	}

	/**
	 * Sort the array points[] by y-coordinate in the non-decreasing order.  Have quicksorter
	 * invoke quicksort() with a comparator object which uses the compareTo() method of the Point
	 * class. Copy the sorted sequence onto the array pointsNoDuplicate[] with duplicates removed.
	 *
	 * Ought to be private, but is made public for testing convenience.
	 */
	public void removeDuplicates() { // DONE

		//// 1. Count duplicates in points[] ////

		// Find out how many duplicates there are in the array
		int numDuplicates = 0; // The number of extra elements that exist in points[]
		for (int i = 0; i < points.length - 1; i++) { // The current element being analyzed
			for (int j = i + 1; j < points.length; j++) { // The elements being compared to the current element
				// If there are unnecessary elements in the array
				if (points[i] == points[j]) {
					numDuplicates++; // Increment numDuplicates
				}
			}
		}

		//// 2. Instantiate variables and perform quick sort on points[]

		// Create a comparator object for the quick sort
		ComparatorHelper<Point> comp = new ComparatorHelper<Point>();
		// Invoke the quick sorter
		quicksorter.quickSort(comp); // Sorts points[]
		// Instantiate the pointsNoDuplicate array with the correct size
		pointsNoDuplicate = new Point[points.length - numDuplicates];

		//// 3. Remove the duplicates from points[] and add to the array pointsNoDuplicate[]

		int pndIndex = 0; // The current index of pointsNoDuplicate

		for (int i = 0; i < points.length - 1; i++) { // The current element
			
			// Variables for the current and next points
			Point current = points[i];
			Point next = points[i + 1];

			// If the array is filled, break
			if (pndIndex == pointsNoDuplicate.length) {
				break;
			}
			
			// If the last index has been reached
			if (i == points.length - 2) {
				pointsNoDuplicate[pndIndex] = next; // Add the last element to the array
				pndIndex++; // Will break the loop automatically
			}
			
			// If the next point is NOT the same as the current
			if (!current.equals(next)) {
				pointsNoDuplicate[pndIndex] = current; // Add the current point to the no duplicates array
				pndIndex++; // Increment the index
			}
		}

		// Update lowestPoint and points
		lowestPoint = pointsNoDuplicate[0];
	}
}
