package hw4;

import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Comparator;

public class JarvisMarch extends ConvexHull {
	// last element in pointsNoDuplicate(), i.e., highest of all points (and the rightmost one in case of a tie)
	private Point highestPoint;

	// left chain of the convex hull counterclockwise from lowestPoint to highestPoint
	private PureStack<Point> leftChain;

	// right chain of the convex hull counterclockwise from highestPoint to lowestPoint
	private PureStack<Point> rightChain;


	/**
	 * Call corresponding constructor of the super class. Initialize the variable algorithm
	 * (from the class ConvexHull). Set highestPoint. Initialize the two stacks leftChain
	 * and rightChain.
	 *
	 * @throws IllegalArgumentException  when pts.length == 0
	 */
	public JarvisMarch(Point[] pts) throws IllegalArgumentException { // DONE
		// Call corresponding super constructor
		super(pts);

		// Super constructor handles exceptions already

		// Initialize algorithm and variables
		algorithm = "Jarvis' march";
		highestPoint = pointsNoDuplicate[pointsNoDuplicate.length - 1];
		leftChain = new ArrayBasedStack<Point>();
		rightChain = new ArrayBasedStack<Point>();
	}


	/**
	 * Call corresponding constructor of the superclass.  Initialize the variable algorithm.
	 * Set highestPoint.  Initialize leftChain and rightChain.
	 *
	 * @param  inputFileName
	 * @throws FileNotFoundException
	 * @throws InputMismatchException   when the input file contains an odd number of integers
	 */
	public JarvisMarch(String inputFileName) throws FileNotFoundException, InputMismatchException { // CHECK AGAIN
		// Call corresponding super constructor
		super(inputFileName);

		// Super constructor handles exceptions already

		// Initialize algorithm and variables
		algorithm = "Jarvis' march";
		highestPoint = pointsNoDuplicate[pointsNoDuplicate.length - 1];
		leftChain = new ArrayBasedStack<Point>();
		rightChain = new ArrayBasedStack<Point>();
	}


	// ------------
	// Javis' march
	// ------------

	/**
	 * Calls createRightChain() and createLeftChain().  Merge the two chains stored on the stacks
	 * rightChain and leftChain into the array hullVertices[].
	 *
     * Two degenerate cases below must be handled:
     *
     *     1) The array pointsNoDuplicates[] contains just one point, in which case the convex
     *        hull is the point itself.
     *
     *     2) The array contains collinear points, in which case the hull is the line segment
     *        connecting the two extreme points from them.
	 */
	public void constructHull() {
		// Create the left and right chains
		createRightChain();
		createLeftChain();

		// Initialize the hullVertices array with the appropriate size
		hullVertices = new Point[rightChain.size() + leftChain.size()];

		// Fill the array with the vertices
		for (int i = hullVertices.length - 1; i > -1; i--) { // Step through hullVertices[] backwards
			if (leftChain.isEmpty() == false) {
				hullVertices[i] = leftChain.pop();
			}
			else {
				hullVertices[i] = rightChain.pop();
			}
		}
	}

	/**
	 * Construct the right chain of the convex hull.  Starts at lowestPoint and wrap around the
	 * points counterclockwise.  For every new vertex v of the convex hull, call nextVertex()
	 * to determine the next vertex, which has the smallest polar angle with respect to v.  Stop
	 * when the highest point is reached.
	 *
	 * Use the stack rightChain to carry out the operation.
	 *
	 * Ought to be private, but is made public for testing convenience.
	 */
	public void createRightChain() { // DONE
		// Start at the lowestPoint and move counter-counterclockwise
		// until the highestPoint is met, to create the right side of the hull

		rightChain.push(lowestPoint); // Push the lowestPoint onto the stack

		int index = 0; // The current index to be incremented

		while (pointsNoDuplicate[index].equals(highestPoint)) {
			rightChain.push(nextVertex(rightChain.peek())); // Push the next vertex onto the stack
			index++; // Increment the index
		}
	}

	/**
	 * Construct the left chain of the convex hull.  Starts at highestPoint and continues the
	 * counterclockwise wrapping.  Stop when lowestPoint is reached.
	 *
	 * Use the stack leftChain to carry out the operation.
	 *
	 * Ought to be private, but is made public for testing convenience.
	 */
	public void createLeftChain() { // DONE
		// Starts at highestPoint and continues the
		// counterclockwise wrapping

		leftChain.push(highestPoint); // Push the highestPoint onto the stack

		int index = pointsNoDuplicate.length - 1; // The current index to be decremented

		while (!pointsNoDuplicate[index].equals(lowestPoint)) {
			leftChain.push(nextVertex(leftChain.peek())); // Push the next vertex onto the stack
			index--; // Decrement the index
		}
	}

	/**
	 * Return the next vertex, which is less than all other points by polar angle with respect
	 * to the current vertex v. When there is a tie, pick the point furthest from v. Comparison
	 * is done using a PolarAngleComparator object created by the constructor call
	 * PolarAngleCompartor(v, false).
	 *
	 * Ought to be private. Made public for testing.
	 *
	 * @param v  current vertex
	 * @return
	 */
	public Point nextVertex(Point v) { // DONE

		// 1. Initialize variables
		Comparator<Point> comp = new PolarAngleComparator(v, false); // The comparator to use
		Point smallest = pointsNoDuplicate[0]; // Holds the vertex less than all other points

		// 2. Step through the array and compare the points
		for (int i = 0; i < pointsNoDuplicate.length; i++) {
			if (comp.compare(smallest, pointsNoDuplicate[i]) > 0) {
				smallest = pointsNoDuplicate[i];
			}
		}

		// 3. Return the smallest point
		return smallest;
	}
}
