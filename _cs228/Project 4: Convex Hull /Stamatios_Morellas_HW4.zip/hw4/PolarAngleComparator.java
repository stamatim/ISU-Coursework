package hw4;

/**
 *
 * @author Stamatios Morellas (morellas@iastate.edu)
 *
 */

import java.util.Comparator;

/**
 *
 * This class compares two points p1 and p2 by polar angle with respect to a reference point.
 *
 */
public class PolarAngleComparator implements Comparator<Point> { // DONE
	private Point referencePoint;
	private boolean flag;  // used for breaking a tie between two points that have
	                       // the same polar angle with respect to referencePoint

	/**
	 * @param p reference point
	 */
	public PolarAngleComparator(Point p, boolean flag) { // DONE
		referencePoint = p;
		this.flag = flag;
	}

	/**
	 * Use cross product and dot product to implement this method.  Do not take square roots
	 * or use trigonometric functions. Calls private methods crossProduct() and dotProduct().
	 *
	 * Precondition: both p1 and p2 are different from referencePoint.
	 *
	 * @param p1
	 * @param p2
	 * @return  0 if p1 and p2 are the same point
	 *         -1 if one of the following three conditions holds:
	 *                a) the cross product between p1 - referencePoint and p2 - referencePoint
	 *                   is greater than zero.
	 *                b) the above cross product equals zero, flag == true, and p1 is closer to
	 *                   referencePoint than p2 is.
	 *                c) the above cross product equals zero, flag == false, and p1 is further
	 *                   from referencePoint than p2 is.
	 *          1  otherwise.
	 *
	 */
	@Override
	public int compare(Point p1, Point p2) { // DONE
		// Create 2 temporary points considering the reference point
		Point temp1 = new Point((p1.getX() - referencePoint.getX()), (p1.getY() - referencePoint.getY()));
		Point temp2 = new Point((p2.getX() - referencePoint.getX()), (p2.getY() - referencePoint.getY()));
		
		int result; // The resulting integer that will be returned
		
		// If p1 and p2 are the same point, return 0
		if (p1.compareTo(p2) == 0) {
			result = 0;
		}
		// If the cross product between p1 - referencePoint and p2 - referencePoint
		// is greater than 0, return -1
		else if (crossProduct(temp1, temp2) > 0) {
			result = -1;
		}
		// If the above cross product equals zero, flag == true, and p1 is closer to
		// referencePoint than p2 is, return -1
		else if (crossProduct(temp1, temp2) == 0 && flag && dotProduct(p1, referencePoint) > dotProduct(p2, referencePoint)) {
			result = -1;
		}
		// If the above cross product equals zero, flag == false, and p1 is further
		// from referencePoint than p2 is, return -1
		else if (crossProduct(temp1, temp2) == 0 && !flag && dotProduct(p1, referencePoint) < dotProduct(p2, referencePoint)) {
			result = -1;
		}
		// Otherwise, return 1
		else {
			result = 1;
		}
		// Return the result
		return result;
	}

  /**
   *
   * @param p1
   * @param p2
   * @return cross product of two vectors: p1 - referencePoint and p2 - referencePoint
   */
  private int crossProduct(Point p1, Point p2) { // DONE
	  // Return the cross product
	  return (p1.getX() * p2.getY()) - (p2.getX() * p1.getY());
  }

  /**
   *
   * @param p1
   * @param p2
   * @return dot product of two vectors: p1 - referencePoint and p2 - referencePoint
   */
  private int dotProduct(Point p1, Point p2) { // DONE
		// Return the dot product
		return (p1.getX() * p2.getX()) + (p1.getY() * p2.getY());
  }
}
