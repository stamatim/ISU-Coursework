package hw4;

import java.util.Comparator;

public class ComparatorHelper <E extends Comparable<E>> implements Comparator<E>{

	@Override
	public int compare(E p1, E p2) {
		if(p1 == null || p2 == null) {
			System.out.println();
		}
		return p1.compareTo(p2);
	}
}
