package hw3;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * @author Stamati Morellas – morellas@iastate.edu
 */

/**
 * This class describes a circular doubly-linked list of states to represent both the OPEN and CLOSED lists
 * used by the A* algorithm. The states on the list are sorted in the
 *
 *     a) order of non-decreasing cost estimate for the state if the list is OPEN, or
 *     b) lexicographic order of the state if the list is CLOSED.
 *
 */
public class OrderedStateList {

	/**
	 * Implementation of a circular doubly-linked list with a dummy head node.
	 */
	  private State head;           // dummy node as the head of the sorted linked list
	  private int size = 0;

	  private boolean isOPEN;       // true if this OrderedStateList object is the list OPEN and false
	                                // if the list CLOSED.

	  /**
	   *  Default constructor constructs an empty list. Initialize heuristic. Set the fields next and
	   *  previous of head to the node itself. Initialize instance variables size and heuristic.
	   *
	   * @param h
	   * @param isOpen
	   */
	  public OrderedStateList(Heuristic h, boolean isOpen) { // DONE
			// Initialize heuristic
			State.heu = h;
			// Initialize isOpen
			this.isOPEN = isOpen;
			// Initialize size
			size = 0;
			// Set fields next and previous of head to the node itself
			head.next = head;
			head.previous = head;
	  }

		/**
		 * Return the size
		 *
		 * @return size
		 */
	  public int size() { // DONE
		  return size;
	  }

	  /**
	   * A new state is added to the sorted list.  Traverse the list starting at head.  Stop
	   * right before the first state t such that compare(s, t) <= 0, and add s before t. If
	   * no such state exists, simply add s to the end of the list.
	   *
	   * Precondition: s does not appear on the sorted list.
	   *
	   * @param s
	   */
	  public void addState(State s) { // NOT WORKING
			// Create a temporary state pointer
			State temp = head;
			// Variable for index
			int i = 0;
			// Iterate through to find where to add State s
			while (i < size) {
				// If s is less than or equal to temp, add s before temp
				if (compareStates(s, temp) <= 0) {
					// Add the pointers from the new state
					s.next = temp;
					s.previous = temp.previous;
					// Reassign the existing pointers
					temp.previous = s;
					s.previous.next = s;
				}
				// Move to the next node
				else {
					temp = temp.next;
				}
				// Increment the index
				i++;
			}
			// If there wasn't a match of where to add the state
			if (i + 1 == size) {
				temp.next = s;
				temp.next.previous = temp;
			}
			// Increase the size
			size++;
	  }

	  /**
	   * Conduct a sequential search on the list for a state that has the same board configuration
	   * as the argument state s.
	   *
	   * Calls compareStates().
	   *
	   * @param s
	   * @return the state on the list if found
	   *         null if not found
	   */
	  public State findState(State s) { // DONE
			// Temporary state
			State temp = head;
			// Variable for index
			int i = 0;
			// Iterate through until a match is found
			while (i < size) {
				// If a match is found
				if (compareStates(s, temp) == 0) {
					// Return the state on the list
					return temp;
				}
				// Otherwise, go to the next State
				else {
					temp = temp.next;
				}
				// Increase the size
				i++;
			}
			// Return null if no match is found
			return null;
	  }

	  /**
	   * Remove the argument state s from the list. It is used by the A* algorithm in maintaining
	   * both the OPEN and CLOSED lists.
	   *
	   * @param s
	   * @throws IllegalStateException if s is not on the list
	   */
	 	public void removeState(State s) throws IllegalStateException { // DONE
			// Temporary state
			State temp = head;
			// Variable for index
			int i = 0;
			// While the index is less than the total size
			while (i < size) {
				// Iterate to the next node
				temp = temp.next;
				// If there's a match
				if (temp == s) {
					// Reasssign the pointers
					temp.previous.next = temp.next;
					temp.next.previous = temp.previous;
					// Set the head to be null
					head = null;
					// Decrease the size
					size--;
					// Stop running the method
					return;
				}
				// Increment the index
				i++;
			}
	  }

	  /**
	   * Remove the first state on the list and return it.  This is used by the A* algorithm in maintaining
	   * the OPEN list.
	   *
	   * @return
	   */
	  public State remove() { // DONE
			// Create a temporary state pointer
			State temp = head;
			// Remove and return the first state on the list
			head.next.previous = null;
			head = head.next;
		  return temp;
	  }

	  /**
	   * Compare two states depending on whether this OrderedStateList object is the list OPEN
	   * or the list CLOSE used by the A* algorithm. More specifically,
	   *
	   *     a) call the method compareTo() of the State if isOPEN == true, or
	   *     b) create a StateComparator object to call its compare() method if isOPEN == false.
	   *
	   * @param s1
	   * @param s2
	   * @return
	   */
	  private int compareStates(State s1, State s2) { // DONE
			// If isOPEN is true
			if (isOPEN) {
				return s1.compareTo(s2);
			}
			// If isOPEN is false
			else {
				// Create a new StateComparator object
				StateComparator comp = new StateComparator();
				// Use the compare() method from StateComparator to compare the two states
				return comp.compare(s1, s2);
			}
	  }
}
