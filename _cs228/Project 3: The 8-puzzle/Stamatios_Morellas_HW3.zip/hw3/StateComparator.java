package hw3;

import java.util.Comparator;

/**
 * @author Stamati Morellas – morellas@iastate.edu
 */

/**
 * This method compares two states in the lexicographical order of the board configuration.
 * The 3X3 array representing each board configuration is converted into a sequence of nine
 * digits starting at the 0th row, and within each row, at the 0th column.  For example, the
 * two states
 *
 * 	   2 0 3        2 8 1
 *     1 8 4        7 5 3
 *     7 6 5        6 0 4
 *
 * are converted into the sequences <2,0,3,1,8,4,7,6,5>, and <2,8,1,7,5,3,6,0,4>, respectively.
 * By definition the first state is less than the second one.
 *
 * The comparator will be used for maintaining the CLOSED list used in the A* algorithm.
 */
public class StateComparator implements Comparator<State> { // DONE
	@Override
	public int compare(State s1, State s2) { // DONE
		// The value to be returned
		int result = 0;
		// Step through the board rows
		for (int i = 0; i < 3; i++) {
			// Step through the board columns
			for (int j = 0; j < 3; j++) {
				// The current number of the s1 board
				int n1 = s1.board[i][j];
				// The current number of the s2 board
				int n2 = s2.board[i][j];
				// Compare the values
				if (n1 < n2) {
					return -1;
				}
				else if (n1 > n2) {
					return 1;
				}
				else {
					result = 0;
				}
			}
		}
		return result;
	}
}
