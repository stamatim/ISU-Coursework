package hw3;

/**
 *
 * Different moves on the board
 *
 */
public enum Move {
	LEFT, RIGHT, UP, DOWN
}
