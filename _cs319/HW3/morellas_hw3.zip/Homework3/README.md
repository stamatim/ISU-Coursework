# CS319 - Homework 3: Event Handling and Node JS
## Part 1: Snake Game
1. Open up the file in Google Chrome by entering the project directory into your browser
2. There are 4 buttons: `start`, `stop`, `left`, and `right` - Press `start` to begin the game
3. Press the `left` and `right` buttons to change the direction of the snake
4. Press the `stop` button to terminate the game
5. To start a new game, refresh the browser and repeat steps 4-4 as desired

## Part 2: Console Calculator
1. To run the calculator, open terminal and `cd` into the directory where you will find the file `calculator.js`
2. To run the app, type in the following command into the terminal: `$ node calculator.js`
3. Enter enter 4 numbers of your choice and view the results in the console output
