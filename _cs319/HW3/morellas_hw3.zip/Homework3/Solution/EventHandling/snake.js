//////////////////// VARIABLES ////////////////////
var canvas = document.getElementById("myCanvas"); // The canvas element
var ctx = canvas.getContext("2d"); // Create a drawing object for the canvas
var btnStart = document.getElementById("btnStart"); // The start button
var btnStop = document.getElementById("btnStop"); // The stop button
var btnLeft = document.getElementById("btnLeft"); // The move left button
var btnRight = document.getElementById("btnRight"); // The move right button

var xpos = 0; // The current x coordinate
var ypos = 300; // The current y coordinate
var state = 1;

ctx.strokeStyle = "red";

btnStart.onclick = function () {
    ctx.beginPath();
    timer = setInterval(function () {
        // Handle boundaries
        if (xpos < 0 || xpos > 800 || ypos < 0 || ypos > 600) {
            clearInterval(game);
            alert("You hit the edge");
        }
        // Handle left click
        btnLeft.onclick = function () {
            state++;
        }

        // Handle right click
        btnRight.onclick = function () {
            state--;
        }

        // Snake moves right
        if (state == 1 || state == 5) {
            state = 1; // reset the state if equal to 5
            xpos++;
            ctx.lineTo(xpos, ypos);
            ctx.stroke();
        }
        // Snake moves down
        if (state == 2) {
            ypos--;
            ctx.lineTo(xpos, ypos);
            ctx.stroke();
        }
        // Snake moves left
        if (state == 3) {
            xpos--;
            ctx.lineTo(xpos, ypos);
            ctx.stroke();
        }
        // Snake moves up
        if (state == 4 || state == 0) {
            state = 4; // reset the state if equal to 0
            ypos++;
            ctx.lineTo(xpos, ypos);
            ctx.stroke();
        }
    }, 20);
}
// Handle stop
btnStop.onclick = function () {
    clearInterval(timer);
    alert("Game Finished!");
}