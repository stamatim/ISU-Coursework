// Use readline-sync
const rs = require('readline-sync');

// Take 4 integer numbers as input
var fNum1 = rs.question("Enter the first number: ");
var fNum2 = rs.question("Enter the second number: ");
var fNum3 = rs.question("Enter the third number: ");
var fNum4 = rs.question("Enter the fourth number: ");

// Calculate the factorial of the first number
function factorialize(number) {
    if (number < 0) {
        return -1;
    } else if (number == 0) {
        return 1;
    } else {
        return (number * factorialize(number - 1));
    }
}
var factorial = factorialize(fNum1);
console.log("The factorial of the first number is " + factorial);

// Calculate the sum of all the digits of the second number
function sumDigits(number) {
    var sum = 0;
    while (number) {
        sum += number % 10;
        number = Math.floor(number / 10);
    }
    return sum;
}
var sumOfDigits = sumDigits(fNum2);
console.log("The sum of all the digits of the second number is " + sumOfDigits);

// Show the reverse of the third number as an output
function reverseNum(number) {
    number = number + "";
    return number.split("").reverse().join("");
}
var reverse = reverseNum(fNum3);
console.log("The reverse of the third number is " + reverse);

// Check if the fourth number is a palindrome
function checkPalindrome(number) {
    if (reverseNum(fNum4) == fNum4) {
        return true;
    } else {
        return false;
    }
}
var isPalindrome = checkPalindrome(fNum4);
console.log("Is the fourth number a palindrome (true/false)? " + isPalindrome);