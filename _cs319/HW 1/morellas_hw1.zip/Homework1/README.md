# COM S 319 [Spring 2019] – Project 1: Server/Client Threads and Sockets
This program was an experiment on using sockets to connect clients to servers and 

## Compiling and Running
Follow these steps to see the execution of the program
1. Open the **Homework1** folder in your Eclipse workspace and navigate to the `Server.java` and `Client.java` files
2. Run `Server.java` as a Java application and you will see that the server starts up and is waiting for clients to connect to it. 
3. Run `Client.java` as a Java application and enter your name when prompted. Once your name has been entered, the messages you type in the client console will show up on the server one as well. 
4. To exit the program, type the word `exit` in the client console and all of the sockets and I/O streams should close successfully.