package thread;

import java.io.IOException;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    // variables for the server class
    private Socket socket = null;
    private ServerSocket serverSocket = null;
    private DataInputStream input = null;
    private int clientNumber = 0;

    // constructor for the server class
    public Server(int portNumber) {
        
        // start the server
        try {
            serverSocket = new ServerSocket(portNumber); // initialize the server socket
            System.out.println("Starting the server...");

            System.out.println("Waiting for client...");

            socket = serverSocket.accept();
            System.out.println("Client " + (clientNumber + 1) + " has been connected to the server!");

            input = new DataInputStream(new BufferedInputStream(socket.getInputStream())); // get the input from the client socket

            String message = ""; // the input message from the client socket

            // looks for user to type in the word exit to stop stream
            while (!message.equals("exit")) {
                try {
                    message = input.readUTF(); // read the input message
                    System.out.println(message); // print the message to the console
                } catch (EOFException e) {
                    e.printStackTrace();
                }
            }
            
            // close connections
            try {
                input.close(); // close the input stream
                socket.close(); // close the socket
                serverSocket.close(); // close the server socket
                System.exit(0);
            } catch (IOException e) {
            		e.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void printSocketInfo(Socket s) {
        System.out.print("SOCKET ON SERVER " + Thread.currentThread() + " ");
        System.out.print("SERVER SOCKET LOCAL ADDRESS: " + s.getLocalAddress() + ":" + s.getLocalPort() + " ");
        System.out.println("SERVER SOCKET REMOTE ADDRESS: " + s.getRemoteSocketAddress());
        System.out.println(""); // new line
    }
    
    public static void main(String[] args) {
        Server server = new Server(4444); // Start the server and read inputs
    }

} // end of server class

