package thread;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {

    // object variables
    private static String yourName; // client name
    private static String serverHostName = "localhost"; // server host name
    private static int serverPortNumber = 4444; // server port number
    
    private Socket clientSocket = null; // the socket
    private DataInputStream input = null; // the input stream
    private DataOutputStream output = null; // the output stream

    // the client constructor
    public Client(String clientName, String hostName, int portNumber) {

        // [1.2] establish a connection to the server
        try {
            clientSocket = new Socket(hostName, portNumber); // initialize the socket
            System.out.println("\n" + "[CONNECTED]"); // notify user that they have been connected
            input = new DataInputStream(System.in); // the input stream that will collect client data from the terminal
            output = new DataOutputStream(clientSocket.getOutputStream()); // the output stream that will output to the socket
        } catch (IOException e) {
            e.printStackTrace();
        }

        String message = ""; // reads message

        // inputs will stop being read when the word 'exit' is typed in
        while (!message.equals("exit")) {
            try {
                message = input.readLine();
                output.writeUTF(clientName + ": " + message);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // close the connection with the server
        try {
            output.writeUTF("Input stream terminated by client");
            input.close(); // close the input stream
            output.close(); // close the output stream
            clientSocket.close(); // close the socket
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // prints information about the client-side socket
    static void printSocketInfo(Socket s) {
        System.out.print("SOCKET ON CLIENT-SIDE: ");
        System.out.print("Local Address: " + s.getLocalAddress() + ":" + s.getLocalPort() + " ");
        System.out.println("Remote Address: " + s.getRemoteSocketAddress());
    }

    // running the main method connects the client to the server 
    public static void main(String[] args) throws UnknownHostException, IOException {
        
        // [1.1] prompt the user for their name
        Scanner s = new Scanner(System.in);
        System.out.print("Please enter your name: ");
        yourName = s.next();
        System.out.println(""); // new line
        
        Client client = new Client(yourName, serverHostName, serverPortNumber); // create the client object, which will also connect to the server
        printSocketInfo(client.clientSocket);

        s.close(); // close the scanner
    }
}
