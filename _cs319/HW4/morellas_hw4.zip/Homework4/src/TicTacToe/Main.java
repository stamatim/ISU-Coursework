package TicTacToe;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/*
 * CS319 - Homework 4: Tic-Tac-Toe Game
 * Due: 3/17/19
 * Submitted: 3/15/19
 * @author Stamatios Morellas
 */
public class Main extends JPanel {

    // VARIABLES
    JButton buttons[] = new JButton[9]; // the button array
    private ImageIcon x = new ImageIcon("x.jpg"); // the graphic for player X
    private ImageIcon o = new ImageIcon("o.jpg"); // the graphic for player o
    int turn = 0; // indicates who's move it is - even => o : odd => x

    /*
     * Creates a grid layout of 3 rows by 3 columns for the tic-tac-toe game to be played on.
     * Initializes a button in each space of the grid where an 'x' or 'o' will be placed
     */
    public Main() {
        setLayout(new GridLayout(3, 3));
        btnInit();
    }

    /*
     * Initialize the array of buttons, set listeners, set empty icons, and add the buttons to the panel
     */
    public void btnInit() {
        for (int i = 0; i < 9; i++) { // step through each space in the grid
            buttons[i] = new JButton();
            buttons[i].addActionListener(new btnListener()); // Implement in private class
            buttons[i].setIcon(null);
            add(buttons[i]);
        }
    }

    /*
     * Resets the board after the game is complete to have empty spaces
     */
    public void btnReset() {
        for (int i = 0; i < 9; i++) {
            buttons[i].setIcon(null);
        }
    }


    private class btnListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {

            JButton button = (JButton) e.getSource(); // find which button was clicked

            // if it is player 1's turn, will mark an O in the selected space if empty
            if (turn % 2 == 0 && button.getIcon() == null) {
                button.setIcon(o);
                turn++;
            }

            // if it is player 2's turn, will mark an X in the selected space if empty
            if (turn % 2 != 0 && button.getIcon() == null) {
                button.setIcon(x);
                turn++;
            }

            // check to see how many tiles are filled
            int filled = 0;
            for (int i = 0; i < 9; i++) {
                if (buttons[i].getIcon() != null) {
                    filled++;
                }
            }

            // if game is a draw, notify and reset the board
            if (!checkWin() && filled == 9) {
                JOptionPane.showMessageDialog(null, "The game is a draw! Play again to win", "DRAW", JOptionPane.INFORMATION_MESSAGE);
                btnReset();
            }

            // if game is a win, notify and reset the board
            if (checkWin()) {
                // if player 1 won (O)
                if (turn % 2 != 0) {
                    JOptionPane.showMessageDialog(null, "Congratulations, player 1 wins!", "WINNER", JOptionPane.INFORMATION_MESSAGE);
                }
                // if player 2 won (X)
                else {
                    JOptionPane.showMessageDialog(null, "Congratulations, player 2 wins!", "WINNER", JOptionPane.INFORMATION_MESSAGE);
                }
                btnReset();
                return;
            }

            // notify what player's turn it is - do this after a win is checked for
            if (turn % 2 == 0) {
                JOptionPane.showMessageDialog(null, "Player 1's turn, make your move...", "Player 1", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Player 2's turn, make your move...", "Player 2", JOptionPane.INFORMATION_MESSAGE);
            }
        }

        /*
         * Checks for a series of 3 in a row
         *
         * @param index 1, index 2, index 3
         * @return true or false
         */
        private boolean checkThree(int a, int b, int c) {
            if ((buttons[a].getIcon() == x && buttons[b].getIcon() == x && buttons[c].getIcon() == x) ||
                    (buttons[a].getIcon() == o && buttons[b].getIcon() == o && buttons[c].getIcon() == o)) {
                return true;
            } else {
                return false;
            }
        }

        /*
         * Checks for a series of 3-in-a-row of either x or o. Returns true if a player has won
         * Check vertical, horizontal, diagonal
         *
         * The indices of the buttons on the board:
         * 0 | 1 | 2
         * 3 | 4 | 5
         * 6 | 7 | 8
         *
         * @return true or false
         */
        private boolean checkWin() {

            // check vertical win
            if (checkThree(0, 3, 6) ||
                checkThree(1, 4, 7) ||
                checkThree(2, 5, 8)) {
                return true;
            }

            // check horizontal win
            else if (checkThree(0, 1, 2) ||
                     checkThree(3, 4, 5) ||
                     checkThree(6, 7, 8)) {
                return true;
            }

            // check diagonal win
            else if (checkThree(0, 4, 8) ||
                     checkThree(6, 4, 2)) {
                return true;
            }

            // default
            else {
                return false;
            }
        }
    }

    /*
     * Starts the Tic-Tac-Toe Game
     */
    public static void main(String[] args) {
        JFrame window = new JFrame("Tic-Tac-Toe Game");
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.getContentPane().add(new Main());
        window.setSize(900,900);
        window.setVisible(true);
        JOptionPane.showMessageDialog(null, "Player 1, you go first...", "Player 1", JOptionPane.INFORMATION_MESSAGE);
    }
}

