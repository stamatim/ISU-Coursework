# CS319 - Homework 4: Tic-Tac-Toe Game

## How to play the game:
1. Load up your favorite IDE (I personally used IntelliJ IDEA but Eclipse works also)
2. Press the green play button to compile and run the program
3. Play tic tac toe (by yourself or with someone else)
