// Checks all validations
function validateAll() {
    if (validateFirst() && validateLast() && validateGender() && validateState()) {
        return true;
    } else {
        return false;
    }
}

// The function that will valiate the first name field
function validateFirst() {
    var field = document.forms["validation"]["firstname"].value; 
    // Check if filled out
    if (field == "") {
        alert("Please enter a firstname");
        document.getElementById("First").appendChild(getImage(false, "firstname"));
        return false;
    } 
    // Check for alphanumeric numbers 
    else if (!checkAlphanumeric(field)) {
        alert("Please only use alphanumeric numbers");
        document.getElementById("First").appendChild(getImage(false, "firstname"));
        return false;
    } 
    // If all conditions pass, return true
    else {
        document.getElementById("First").appendChild(getImage(true, "firstname"));
        return true;
    }
}

// The function that will validate the last name field
function validateLast() {
    var field = document.forms["validation"]["lastname"].value; 
    // Check if filled out
    if (field == "") {
        alert("Please enter a lastname");
        document.getElementById("Last").appendChild(getImage(false, "lastname"));
        return false;
    }
    // Check for alphanumeric numbers 
    else if (!checkAlphanumeric(field)) {
        alert("Please only use alphanumeric numbers");
        document.getElementById("Last").appendChild(getImage(false, "lastname"));
        return false;
    }
    // If all conditions pass, return true
    else {
        document.getElementById("Last").appendChild(getImage(true, "lastname"));
        return true;
    }
}

// The function that will validate the gender field
function validateGender() {
    var ddl = document.getElementById("gender");
    var selectedValue = ddl.options[ddl.selectedIndex].value;
    // If no value has been selected
    if (selectedValue == "select") {
        alert("Please select your gender");
        document.getElementById("Gender").appendChild(getImage(false, "gender"));
        return false;
    } 
    // If a value has been selected
    else {
        document.getElementById("Gender").appendChild(getImage(true, "gender"));
        return true;
    }
}

// The function that will validate the state field
function validateState() {
    var ddl = document.getElementById("state");
    var selectedValue = ddl.options[ddl.selectedIndex].value;
    // If no value has been selected
    if (selectedValue == "select") {
        alert("Please select a state");
        document.getElementById("State").appendChild(getImage(false, "state"));
        return false;
    }
    // If a value has been selected
    else {
        document.getElementById("State").appendChild(getImage(true, "state"));
        return true;
    }
}

// Outputs the correct image based on if validation is correct or incorrect
function getImage(status, id) {
    var image = document.getElementById("image" + id);
    if (image == null) {
        image = new Image(15, 15);
        image.id = "image" + id;
    }
    image.src = status ? 'correct.png' : 'wrong.png';
    return image;
}

// Function that checks for alphanumeric numbers
function checkAlphanumeric(input) {
    let regex = /^[a-z0-9]+$/i; 
    if (input != null && input.match(regex)) {
        return true;
    } else {
        return false;
    }
}


