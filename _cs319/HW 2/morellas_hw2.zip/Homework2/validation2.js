// Check all validations
function validateAll() {
    if (validateEmail() && validatePhone() && validateAddress()) {
        return true;
    }
    else {
        return false;
    }
}

function validateEmail() {
    var field = document.forms["contact"]["email"].value; 
    // Check if filled out
    if (field == "") {
        alert("Please enter a valid email address");
        document.getElementById("Email").appendChild(getImage(false, "email"));
        return false;
    }
    // Check email format
    else if (!checkEmail(field)) {
        alert("Please make sure your email is formatted correctly");
        document.getElementById("Email").appendChild(getImage(false, "email"));
        return false;
    }
    // If everything looks good
    else {
        document.getElementById("Email").appendChild(getImage(true, "email"));
        return true;
    }
}

function validatePhone() {
    var field = document.forms["contact"]["phone"].value;
    // Check if filled out
    if (field == "") {
        alert("Please enter a valid phone number");
        document.getElementById("Phone").appendChild(getImage(false, "phone"));
        return false;
    }
    // Check phone format
    else if (!checkPhone(field)) {
        alert("Please make sure your phone number is formatted correctly");
        document.getElementById("Phone").appendChild(getImage(false, "phone"));
        return false;
    }
    // If everything looks good
    else {
        document.getElementById("Phone").appendChild(getImage(true, "phone"));
        return true;
    }
}

function validateAddress() {
    var field = document.forms["contact"]["address"].value;
    // Check if filled out
    if (field == "") {
        alert("Please enter a valid address");
        document.getElementById("Address").appendChild(getImage(false, "address"));
        return false;
    }
    // Check address format
    else if (!checkAddress(field)) {
        alert("Please check the format of your addresss");
        document.getElementById("Address").appendChild(getImage(false, "address"));
        return false;
    }
    // If everything looks good
    else {
        document.getElementById("Address").appendChild(getImage(true, "address"));
        return true;
    }
}

// Outputs the correct image based on if validation is correct or incorrect
function getImage(status, id) {
    var image = document.getElementById("image" + id);
    if (image == null) {
        image = new Image(15, 15);
        image.id = "image" + id;
    }
    image.src = status ? 'correct.png' : 'wrong.png';
    return image;
}

// Function that checks for alphanumeric numbers
function checkAlphanumeric(input) {
    let regex = /^[a-z0-9]+$/i;
    if (input != null && input.match(regex)) {
        return true;
    } else {
        return false;
    }
}

// Check email formatting
function checkEmail(email) {
    var atSplit = email.split('@');
    if (atSplit.length == 2 && checkAlphanumeric(atSplit[0])) {
        periodSplit = atSplit[1].split('.')
        if (periodSplit.length == 2 && checkAlphanumeric(periodSplit[0] + periodSplit[1])) {
            return true;
        }
    }
    return false;
}

// Checks formatting of phone number
function checkPhone(number) {
    var regex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if (number.value.match(regex)) {
        return true;
    } else {
        return false;
    }

}

// Checks formatting of address
function checkAddress(address) {
    var regex = /[\w ]+,\w{2}/;
    if (address.match(regex)) {
        return true;
    } else {
        return false;
    }
}