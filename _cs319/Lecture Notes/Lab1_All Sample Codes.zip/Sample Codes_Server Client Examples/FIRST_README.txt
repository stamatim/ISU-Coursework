README.txt
-----------------------------------------------------------------

First run MyServer.java 
Then, you can run several MyClient.java programs and see what happens.
This is a very basic example of server client.


ListServer.java and ListClient.java have a more interactive
communication between the server and client.


MyBrowser.java tries to give some idea of how a browser like Chrome
would work. You can type an address (like www.google.com) and a port
(80) and see it talk to google's server. It will basically send HTTP
Requests.


MyWebServer.java tries to give some idea of how a server like Apache etc
would work. Essentially, it will need to understand HTTP Requests and
send back HTTP Responses. You can even connect to this server by using
the MyBrowser.java client.
-----------------------------------------------------------------
