# COM S 352 - Project 2
Author: Stamatios Morellas - morellas@iastate.edu
Documentation: See `main.c` for inline comments

## Overview

In this project we are asked to synchronize multiple threads. The project must be written in C, and must use the pthreads library. The purpose of this project is to implement a multi-threaded text file encryptor. Conceptually, the function of the program is simple: to read characters from the input file, encrypt the letters, and write the encrypted characters to the output file. Also, the encryption program counts the number of occurrences of each letter in the input and output files.