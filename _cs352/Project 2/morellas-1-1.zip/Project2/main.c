#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>

#include <ctype.h>

#define NUM_THREADS 6 /* total number of threads */

/* Declare shared variables */
typedef struct buffer_t {
	int nextin;
	int nextout;
	FILE* file;
} buffer_t;

buffer_t* input;
char* in_buffer;
sem_t in_mutex;
sem_t in_empty;
sem_t in_full;
int in_ct[26]; // hold letter count for each letter
sem_t in_count; // for input counter thread

buffer_t* output;
char* out_buffer;
sem_t out_mutex;
sem_t out_empty;
sem_t out_full;
int out_ct[26];
sem_t out_count; // for output counter thread

int buffer_size; /* size for each buffer */

/* Thread function prototypes */
void* runReaderThread(void* arg); /* reader thread runner */
void* runWriterThread(void* arg); /* writer thread runner */
void* runEncryptionThread(void* arg); /* encryption thread runner */
void* runInputCounterThread(void* arg); /* input counter thread runner */
void* runOutputCounterThread(void* arg); /* output counter thread runner */

/*
 * Main thread
 */
int main(int* argc, char** argv) {

	pthread_t reader, writer, encryption, in_counter, out_counter; /* six threads required for project */

	/* 1. Obtain the input and output files */
	if (argc > 3) { // Check for number of command line args
		printf("Error: Number of command line arguments exceeds the limit of 2.\n");
		exit(1); // exit with error
	}
	FILE* infile = fopen(argv[1], "r"); /* get the input file from the command line */
	FILE* outfile = fopen(argv[2], "w"); /* get the output file from the command line */

	/* 2. Prompt the user for the buffer size N */
	printf("\nEnter buffer size: ");
	scanf("%d", &buffer_size);
	printf("\n");
	if (buffer_size == 0) {
		printf("Error: Problem reading buffer size.\n");
		exit(2); // exit with error
	}

	// Allocate memory space
	in_buffer = malloc(sizeof(char) * buffer_size + 1);
	out_buffer = malloc(sizeof(char) * buffer_size + 1); 
	input = malloc(sizeof(buffer_t*));
	output = malloc(sizeof(buffer_t*));


	printf("Set buffer to size: %d\n\n", buffer_size); // for debugging


	/* 3. Initialize shared variables */
	// input buffer
	sem_init(&in_mutex, 0, 1);
	sem_init(&in_empty, 0, buffer_size);
	sem_init(&in_full, 0, 0);
	sem_init(&in_count, 0, 0);
	input->nextin = input->nextout = 0;
	input->file = infile;

	// output buffer
	sem_init(&out_mutex, 0, 1);
	sem_init(&out_empty, 0, buffer_size);
	sem_init(&out_full, 0, 0);
	sem_init(&out_count, 0, 0);
	output->nextin = output->nextout = 0;
	output->file = outfile;


	printf("Initialization of shared variables complete. Creating threads...\n\n"); // for debugging


	/* 4. Create other threads */ 
	printf("Creating READER thread...\n");
	pthread_create(&reader, NULL, runReaderThread, input); // start the reader thread in the calling process

	printf("Creating WRITER thread...\n");
	pthread_create(&writer, NULL, runWriterThread, output); // start the writer thread in the calling process

	printf("Creating ENCRYPTION thread...\n");
	pthread_create(&encryption, NULL, runEncryptionThread, input); // start the encryption thread in the calling process
	
	printf("Creating INPUT COUNTER thread...\n");
	pthread_create(&in_counter, NULL, runInputCounterThread, input); // start the input counter thread in the calling process

	printf("Creating OUTPUT COUNTER thread...\n");
	pthread_create(&out_counter, NULL, runOutputCounterThread, output); // start the output counter thread in the calling process

		
	/* 5. Wait for all threads to complete */
	pthread_join(reader, NULL);
	pthread_join(writer, NULL);
	pthread_join(encryption, NULL);
	pthread_join(in_counter, NULL);
	pthread_join(out_counter, NULL);


	/* 6. Display the number of occurrences of each letter in the input and output files */
	printf("Input file contains:\n");
	for (int i = 0; i < 26; i++) {
		switch (i) {
			case 0: 
				if (in_ct[i] > 0) {
					printf("A: %d\n", in_ct[i]);
				}
			case 1:
				if (in_ct[i] > 0) {
					printf("B: %d\n", in_ct[i]);
				}
			case 2:
				if (in_ct[i] > 0) {
					printf("C: %d\n", in_ct[i]);
				}
			case 3:
				if (in_ct[i] > 0) {
					printf("D: %d\n", in_ct[i]);
				}
			case 4:
				if (in_ct[i] > 0) {
					printf("E: %d\n", in_ct[i]);
				}
			case 5:
				if (in_ct[i] > 0) {
					printf("F: %d\n", in_ct[i]);
				}
			case 6:
				if (in_ct[i] > 0) {
					printf("G: %d\n", in_ct[i]);
				}
			case 7:
				if (in_ct[i] > 0) {
					printf("H: %d\n", in_ct[i]);
				}
			case 8:
				if (in_ct[i] > 0) {
					printf("I: %d\n", in_ct[i]);
				}
			case 9:
				if (in_ct[i] > 0) {
					printf("J: %d\n", in_ct[i]);
				}
			case 10:
				if (in_ct[i] > 0) {
					printf("K: %d\n", in_ct[i]);
				}
			case 11:
				if (in_ct[i] > 0) {
					printf("L: %d\n", in_ct[i]);
				}
			case 12:
				if (in_ct[i] > 0) {
					printf("M: %d\n", in_ct[i]);
				}
			case 13:
				if (in_ct[i] > 0) {
					printf("N: %d\n", in_ct[i]);
				}
			case 14:
				if (in_ct[i] > 0) {
					printf("O: %d\n", in_ct[i]);
				}
			case 15:
				if (in_ct[i] > 0) {
					printf("P: %d\n", in_ct[i]);
				}
			case 16:
				if (in_ct[i] > 0) {
					printf("Q: %d\n", in_ct[i]);
				}
			case 17:
				if (in_ct[i] > 0) {
					printf("R: %d\n", in_ct[i]);
				}
			case 18:
				if (in_ct[i] > 0) {
					printf("S: %d\n", in_ct[i]);
				}
			case 19:
				if (in_ct[i] > 0) {
					printf("T: %d\n", in_ct[i]);
				}
			case 20:
				if (in_ct[i] > 0) {
					printf("U: %d\n", in_ct[i]);
				}
			case 21:
				if (in_ct[i] > 0) {
					printf("V: %d\n", in_ct[i]);
				}
			case 22:
				if (in_ct[i] > 0) {
					printf("W: %d\n", in_ct[i]);
				}
			case 23:
				if (in_ct[i] > 0) {
					printf("X: %d\n", in_ct[i]);
				}
			case 24:
				if (in_ct[i] > 0) {
					printf("Y: %d\n", in_ct[i]);
				}
			case 25:
				if (in_ct[i] > 0) {
					printf("Z: %d\n", in_ct[i]);
				}
		}
	}
	printf("Output file contains:\n"); 
	for (int i = 0; i < 26; i++) {
		switch (i) { 
			case 0: 
				if (out_ct[i] > 0) {
					printf("A: %d\n", out_ct[i]);
				}
			case 1:
				if (out_ct[i] > 0) {
					printf("B: %d\n", out_ct[i]);
				}
			case 2:
				if (out_ct[i] > 0) {
					printf("C: %d\n", out_ct[i]);
				}
			case 3:
				if (in_ct[i] > 0) {
					printf("D: %d\n", out_ct[i]);
				}
			case 4:
				if (in_ct[i] > 0) {
					printf("E: %d\n", out_ct[i]);
				}
			case 5:
				if (in_ct[i] > 0) {
					printf("F: %d\n", out_ct[i]);
				}
			case 6:
				if (in_ct[i] > 0) {
					printf("G: %d\n", out_ct[i]);
				}
			case 7:
				if (in_ct[i] > 0) {
					printf("H: %d\n", out_ct[i]);
				}
			case 8:
				if (in_ct[i] > 0) {
					printf("I: %d\n", out_ct[i]);
				}
			case 9:
				if (in_ct[i] > 0) {
					printf("J: %d\n", out_ct[i]);
				}
			case 10:
				if (in_ct[i] > 0) {
					printf("K: %d\n", out_ct[i]);
				}
			case 11:
				if (in_ct[i] > 0) {
					printf("L: %d\n", out_ct[i]);
				}
			case 12:
				if (in_ct[i] > 0) {
					printf("M: %d\n", out_ct[i]);
				}
			case 13:
				if (in_ct[i] > 0) {
					printf("N: %d\n", out_ct[i]);
				}
			case 14:
				if (in_ct[i] > 0) {
					printf("O: %d\n", out_ct[i]);
				}
			case 15:
				if (in_ct[i] > 0) {
					printf("P: %d\n", out_ct[i]);
				}
			case 16:
				if (in_ct[i] > 0) {
					printf("Q: %d\n", out_ct[i]);
				}
			case 17:
				if (in_ct[i] > 0) {
					printf("R: %d\n", out_ct[i]);
				}
			case 18:
				if (in_ct[i] > 0) {
					printf("S: %d\n", out_ct[i]);
				}
			case 19:
				if (in_ct[i] > 0) {
					printf("T: %d\n", out_ct[i]);
				}
			case 20:
				if (in_ct[i] > 0) {
					printf("U: %d\n", out_ct[i]);
				}
			case 21:
				if (in_ct[i] > 0) {
					printf("V: %d\n", out_ct[i]);
				}
			case 22:
				if (in_ct[i] > 0) {
					printf("W: %d\n", out_ct[i]);
				}
			case 23:
				if (in_ct[i] > 0) {
					printf("X: %d\n", out_ct[i]);
				}
			case 24:
				if (in_ct[i] > 0) {
					printf("Y: %d\n", out_ct[i]);
				}
			case 25:
				if (in_ct[i] > 0) {
					printf("Z: %d\n", out_ct[i]);
				}
		}
	}

	/* Destroy mutex and thread conditions before completion */
	sem_destroy(&in_mutex);
	sem_destroy(&in_empty);
	sem_destroy(&in_full);
	sem_destroy(&in_count);
	sem_destroy(&out_mutex);
	sem_destroy(&out_empty);
	sem_destroy(&out_full);
	sem_destroy(&out_count);
	return 0;
}

/*
 * The reader thread is responsible for reading from the input file (specified by the first argument on the command line) 
 * one character at a time, and placing the characters in the input buffer. Each buffer item corresponds to a character. 
 * Note that the reader thread may need to block until other threads have consumed data from the input buffer. 
 *
 * Specifically, a character in the input buffer cannot be overwritten until the encryptor thread and the input counter 
 * thread have processed the character. The reader continues until the end of the input file is reached.
 */
void* runReaderThread(void* arg) {
	buffer_t* in = (buffer_t*) arg;
	char item;
	do {
		sem_wait(&in_empty);
		sem_wait(&in_mutex);

		// perform reading here
		item = fgetc(in->file);
		in_buffer[in->nextin] = item;
		in->nextin++;
		in->nextin = in->nextin % buffer_size;

		sem_post(&in_mutex);
		sem_post(&in_full);
		sem_post(&in_count);
	} while (item != EOF);
}

/*
 * The writer thread is responsible for writing the encrypted characters in the output buffer to the output file 
 * (specified by the second argument on the command line). Note that the writer may need to block until an encrypted 
 * character is available in the buffer. The writer continues until it has written the last encrypted character
 */
void* runWriterThread(void* arg) {
	buffer_t* out = (buffer_t*) arg;
	char item;
	do {
		sem_wait(&out_full);
		sem_wait(&out_mutex);

		// perform writing here 
		item = out_buffer[out->nextout];
		out->nextout++;
		out->nextout = out->nextout % buffer_size;

		sem_post(&out_mutex);
		sem_post(&out_empty);
		sem_post(&out_count);
	} while (item != EOF);
}

/*
 * The encryption thread consumes one character at a time from the input buffer, encrypts it, and places it in the output buffer. 
 * Of course, the encryption thread may need to wait for an item to become available in the input buffer, 
 * and for a slot to become available in the output buffer. Note that a character in the output buffer cannot be
 * overwritten until the writer thread and the output counter thread have processed the character. 
 * The encryption thread continues until all characters of the input file have been encrypted.
 * 
 * The encryption algorithm is fairly simple (and is very easy to crack). 
 * Only alphabetic characters (i.e., 'A'..'Z' and 'a'..'z') are changed; all other characters are simply copied to the output file. 
 * The algorithm either increments, decrements, or does not touch alphabetic characters. The encryption algorithm is as follows.
 * 
 */
void* runEncryptionThread(void* arg) {
	buffer_t* in = (buffer_t*) arg;

	// preform encryption
	int s = 1; // 1. initialize s = 1
	char c;
	do {
		sem_wait(&in_full);
		sem_wait(&in_mutex);

		c = fgetc(in->file); // 2. get next char c
		if (isalpha(c)) { // 3. if c is not a letter, goto (7)
			// 4. if s = 1, then increase c with wraparound
			if (s == 1) { 
				if (c == 'Z') {
					c = 'A';
				} else if (c == 'z') {
					c = 'a';
				} else {
					c++;
				}
				s = -1;
			} 
			// 5. if s = -1, then decreace c with wraparound
			else if (s == -1) { 
				if (c == 'A') {
					c = 'Z';
				} else if (c == 'a') {
					c = 'z';
				} else {
					c--;
				}
				s = 0;
			} 
			// 6. if s = 0, then do not change c and set s = 1
			else {
				s = 1;
			}
		}
		char encrypted = c; // 7. Encrypted character is c
	} while (c != EOF); // 8. if c != EOF, goto (2)


	sem_post(&in_mutex);
	sem_post(&in_empty);
}

/*
 * The input counter thread simply counts occurrences of each letter in the input file by looking at each character 
 * in the input buffer. 
 * Of course, the input counter thread will need to block if no characters are available in the input buffer.
 */
void* runInputCounterThread(void* arg) {
	buffer_t* in = (buffer_t*) arg; 
	FILE* inf = in->file;

	// initialize array
	for (int i = 0; i < 26; i++) {
		in_ct[i] = 0;
	}

	char c;
	// Count occurrences
	do { 
		sem_wait(&in_count);
		sem_wait(&in_mutex);

		c = fgetc(inf);
		switch (c) {
			case 'A':
				in_ct[0]++;
			case 'B':
				in_ct[1]++;
			case 'C':
				in_ct[2]++;
			case 'D':
				in_ct[3]++;
			case 'E':
				in_ct[4]++;
			case 'F':
				in_ct[5]++;
			case 'G':
				in_ct[6]++;
			case 'H':
				in_ct[7]++;
			case 'I':
				in_ct[8]++;
			case 'J':
				in_ct[9]++;
			case 'K':
				in_ct[10]++;
			case 'L':
				in_ct[11]++;
			case 'M':
				in_ct[12]++;
			case 'N':
				in_ct[13]++;
			case 'O':
				in_ct[14]++;
			case 'P':
				in_ct[15]++;
			case 'Q':
				in_ct[16]++;
			case 'R':
				in_ct[17]++;
			case 'S':
				in_ct[18]++;
			case 'T':
				in_ct[19]++;
			case 'U':
				in_ct[20]++;
			case 'V':
				in_ct[21]++;
			case 'W':
				in_ct[22]++;
			case 'X':
				in_ct[23]++;
			case 'Y':
				in_ct[24]++;
			case 'Z':
				in_ct[25]++;
		}
	} while (c != EOF); 
}

/*
 * The output counter thread simply counts occurrences of each letter in the output file 
 * by looking at each character in the output buffer. 
 * Of course, the output counter thread will need to block if no characters are 
 * available in the output buffer.
 */
void* runOutputCounterThread(void* arg) {
	buffer_t* out = (buffer_t*) arg;
	FILE* outf = out->file;

	// initialize array
	for (int i = 0; i < 26; i++) {
		out_ct[i] = 0;
	}

	char c;
	// Count occurrences
	do { 
		sem_wait(&out_count);
		sem_wait(&out_mutex);

		c = fgetc(outf);
		switch (c) {
			case 'A':
				out_ct[0]++;
			case 'B':
				out_ct[1]++;
			case 'C':
				out_ct[2]++;
			case 'D':
				out_ct[3]++;
			case 'E':
				out_ct[4]++;
			case 'F':
				out_ct[5]++;
			case 'G':
				out_ct[6]++;
			case 'H':
				out_ct[7]++;
			case 'I':
				out_ct[8]++;
			case 'J':
				out_ct[9]++;
			case 'K':
				out_ct[10]++;
			case 'L':
				out_ct[11]++;
			case 'M':
				out_ct[12]++;
			case 'N':
				out_ct[13]++;
			case 'O':
				out_ct[14]++;
			case 'P':
				out_ct[15]++;
			case 'Q':
				out_ct[16]++;
			case 'R':
				out_ct[17]++;
			case 'S':
				out_ct[18]++;
			case 'T':
				out_ct[19]++;
			case 'U':
				out_ct[20]++;
			case 'V':
				out_ct[21]++;
			case 'W':
				out_ct[22]++;
			case 'X':
				out_ct[23]++;
			case 'Y':
				out_ct[24]++;
			case 'Z':
				out_ct[25]++;
		}
	} while (c != EOF); 
}





