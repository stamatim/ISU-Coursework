/*
 *	Author: Stamatios Morellas
 *	Class: COM S 352 - Spring 2020
 *
 *	Project 1 - UNIX Shell
 *
 * 		Due 2/14/20 
 */
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>

#define MAX_LINE 80 /* The maximum length command */
#define EXIT_SUCCESS 0 /* Clean exit from the termination of this program */


/* Prototypes */
void checkRedirection(char** args);
void execute(pid_t pid, char** args); 
void parse(char command[], char** args);

int main(void) {
	char* args[MAX_LINE/2 + 1]; /* command line arguments - array of strings */
	char** args_prev; /* previous arguments */

	int should_run = 1; /* flag to determine when to terminate program */
	
	pid_t pid, pid1, pid2; /* process IDs */
	
	char cmd_prev[41] = ""; /* previous command entered */

	int fd[2]; // file descriptors: 1 - reading, 2 - writing


	while(should_run) {
		printf("osh> ");
		fflush(stdout);
		

		/* Read user input */
       		char command[41];		
		scanf("%s", &command);

		/* Check for exit key */
		if (strcmp(command, "exit") == 0) { // user terminates program
			printf("\n\nTerminating program...Goodbye.\n\n");
			should_run = 0;
			exit(0);
		} 

		/* PARSE CURRENT INPUT */
		parse(command, args); 


		/* Handle previous command error  */
		if (strcmp(args[0], "!!") == 0 && strcmp(cmd_prev, "") == 0) {
			printf("\nNo commands in history.\n"); // error
			continue;
		} 

		/* EXECUTE COMMAND */
		if (strcmp(args[0], "!!") == 0) { // execute previous
			printf("Previous cmd --> %s\n\n", cmd_prev); // print previous command
			parse(cmd_prev, args_prev);
			execute(pid, args_prev);
		} else { // execute current
			parse(command, args);
			execute(pid, args);
		}
		
		/* Update previous command and args */
		args_prev = args;
		strcpy(cmd_prev, command);
	}

	return 0;
}

/*
 * Parse the input and updates the args array
 */
void parse(char command[], char** args) {
	const char delim[2] = " "; // delimiter for strtok
	char* token;
	int n = 0; // arg counter

	/* first token */
	token = strtok(command, delim);
	args[n] = token; // update args
	n++;

	while (token != NULL) {
		token = strtok(NULL, delim);
		args[n] = token; // update args array
		n++;
	}
}	


/*
 * Fork a child process using fork(), invoke execvp(), parent invokes wait()
 */
void execute(pid_t pid, char** args) {
	/* fork a child process */
	pid = fork();
	if (pid < 0) {
		printf("\n\nFork Failed\n\n"); // error
		exit(1);
	} else if (pid == 0) { // child process
		/* CHECK FOR I/O REDIRECTION */
		checkRedirection(args);

		execvp(args[0], args);
		// error if below code executes
		printf("\nExec error!\n");
		exit(1);
	} else { /* parent process */
		/* parent process will wait for the child to complete */
		pid = waitpid(pid, NULL, 0);
	}
}

/*
 * Check for I/O redirection characters in command
 */
void checkRedirection(char** args) {
	const size_t length = sizeof(args)/sizeof(args[0]); // size of args
	
	/*
	 * NOTE:
	 *
	 * 	If redirection will occur, there should only be 3 args, i.e
	 * 		args[0] - command
	 * 		args[1] - either '<' or '>'
	 * 		args[2[ - file
	 */
	if (length == 3) {
		int in = strcmp(args[1], "<"); 
		int out = strcmp(args[1], ">");
		if (in == 0) { // input redirection
			int fd_in = open(args[2], O_RDONLY);
			dup2(fd_in, STDIN_FILENO);
			close(fd_in);
		}
		else if (out == 0) { // output redirection
			int fd_out = open(args[2], O_WRONLY);
			dup2(fd_out, STDOUT_FILENO);
			close(fd_out);
		}
		else {
			// something went wrong
		}
	}
}
