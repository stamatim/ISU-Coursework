#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>

/* Do not modify write_pgm() or read_pgm() */ 
// DONE
int write_pgm(char *file, void *image, uint32_t x, uint32_t y) { 
    FILE *o;

    if (!(o = fopen(file, "w"))) {
        perror(file);

        return -1;
    }

    fprintf(o, "P5\n%u %u\n255\n", x, y);

    /* Assume input data is correctly formatted. *
    * There's no way to handle it, otherwise.   */

    if (fwrite(image, 1, x * y, o) != (x * y)) {
        perror("fwrite");
        fclose(o);

        return -1;
    }

    fclose(o);

    return 0;
}

/* A better implementation of this function would read the image dimensions *
 * from the input and allocate the storage, setting x and y so that the     *
 * user can determine the size of the file at runtime.  In order to         *
 * minimize complication, I've written this version to require the user to  *
 * know the size of the image in advance.                                   */
// DONE
int read_pgm(char *file, void *image, uint32_t x, uint32_t y) {
    FILE *f;
    char s[80];
    unsigned i, j;

    if (!(f = fopen(file, "r"))) {
        perror(file);
        return -1;
    }

    if (!fgets(s, 80, f) || strncmp(s, "P5", 2)) {
        fprintf(stderr, "Expected P6\n");
        return -1;
    }

    /* Eat comments */
    do {
        fgets(s, 80, f);
    } while (s[0] == '#');

    if (sscanf(s, "%u %u", &i, &j) != 2 || i != x || j != y) {
        fprintf(stderr, "Expected x and y dimensions %u %u\n", x, y);
        fclose(f);
        return -1;
    }

    /* Eat comments */
    do {
        fgets(s, 80, f);
    } while (s[0] == '#');

    if (strncmp(s, "255", 3)) {
        fprintf(stderr, "Expected 255\n");
        fclose(f);

        return -1;
    }

    if (fread(image, 1, x * y, f) != x * y) {
        perror("fread");
        fclose(f);
        return -1;
    }

    fclose(f);

    return 0;
}

// DONE
int main(int argc, char *argv[]) {
    int8_t image[1024][1024];
    int8_t out[1024][1024];
    
    /* Example usage of PGM functions */
    /* This assumes that motorcycle.pgm is a pgm image of size 1024x1024 */
    read_pgm("bigger_digger.pgm", image, 1024, 1024); // STEP 1: Read motorcycle image

    /* An empty matrix for the output of the X-gradient */ 
    int8_t oX[1024][1024];

    /* An empty matrix for the output of the Y-gradient */
    int8_t oY[1024][1024];

    /* The first convolution matrix used for edge detection */
    int kernelX[3][3] = {{-1, 0, 1}, {-2, 0, 2}, {-1, 0, 1}};

    /* The second convolution matrix used for edge detection */
    int kernelY[3][3] = {{-1, -2, -1}, {0, 0, 0}, {1, 2, 1}};

    /* STEP 2: Apply the first part of the sobel filter (X-gradient) */
    for (int r = 0; r < 1024; r++) { // For each row in the image matrix
        for (int c = 0; c < 1024; c++) { // For each column in the image matrix
            int8_t accumulator = 0;
            
            for (int j = 0; j < 3; j++) { // For each row in the kernel matrix
                for (int i = 0; i < 3; i++) { // For each column in the kernel matrix
                    accumulator = accumulator + kernelX[j][i] * image[r + (j - 2)][c + (i - 2)];
                }
            }

            oX[r][c] = accumulator;
        }
    }

    /* STEP 3: Apply the second part of the sobel filter (Y-gradient) */
    for (int r = 0; r < 1024; r++) { // For each row in the image matrix
        for (int c = 0; c < 1024; c++) { // For each column in the image matrix
            int8_t accumulator = 0;

            for (int j = 0; j < 3; j++) { // For each row in the kernel matrix
                for (int i = 0; i < 3; i++) { // For each column in the kernel matrix
                    accumulator = accumulator + kernelY[j][i] * image[r + (j - 2)][c + (i - 2)];
                }
            }

            oY[r][c] = accumulator;
        }
    }

    /* STEP 4: Combine the two output matrices into the master out using appropriate equation */
    for (int r = 0; r < 1024; r++) {
        for (int c = 0; c < 1024; c++) {
            out[r][c] = sqrt((oX[r][c] * oX[r][c]) + (oY[r][c] * oY[r][c]));
        }
    }

    /* After processing the image and storing your output in "out", write *
    * to motorcycle.edge.pgm.                                            
    */
    write_pgm("bigger_digger.edge.pgm", out, 1024, 1024);
    return 0;
}