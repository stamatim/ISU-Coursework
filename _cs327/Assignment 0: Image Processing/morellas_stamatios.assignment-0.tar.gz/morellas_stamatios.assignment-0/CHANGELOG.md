# Changelog - Project 0: Image Processing

## Jan 23, 2019
Fixed the incorrect output issue. Everything is currently working.

## Jan 21, 2019
Completed main method of program so that it complies with the assignment specifications provided. Encountered an issue where the image output was incorrect. 

## Jan. 19, 2019
Started project