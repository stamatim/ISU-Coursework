# COM S 327 - Project 0: Image Processing

This purpose of this assignment was to generate an output image with a sobel filter given two 1024x1024 images of a motorcycle and an excavator. 

There is one file `sobel.c`, which has 3 methods inside of it:
- `write_pgm`
- `read_pgm`
- `main`

The first two methods were already implemented, and all of the added code can be found inside of the `main` method. 

The process for the functionality of this program is as follows:
1. Use the `read_pgm` method to read the image from the working directory
2. Apply the first part of the sobel filter from the x-kernel (x-gradient)
3. Apply the second part of the sobel filter from the y-kernel (y-gradient)
4. Combine the two previous kernels into the `out` variable and write to the appropriate filename in the directory using the `write_pgm` method