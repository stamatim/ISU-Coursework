#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

struct r_instruction {
	uint32_t Rm;
	uint32_t shamt;
	uint32_t Rn;
	uint32_t Rd;
};

struct i_instruction {
	int32_t immediate;
	uint32_t Rn;
	uint32_t Rd;
};

struct d_instruction {
	uint32_t address;
	uint32_t Rn;
	uint32_t Rt;
};

struct b_instruction {
	int32_t br_address;
};

struct cb_instruction {
	int32_t cond_br_address;
	uint32_t Rt;
};

struct instruction {
	char format;
	uint32_t opcode;
	union {
		struct r_instruction r;
		struct i_instruction i;
		struct d_instruction d;
		struct b_instruction b;
		struct cb_instruction cb;
	} data;
};

typedef struct instruction Instruction;

uint32_t swap_endians(uint32_t value);
uint32_t get_opcode(uint32_t value);
char get_format(uint32_t opcode);
void parse_instruction(uint32_t value, Instruction *inst);
int32_t process_c_instruction(Instruction *inst, int64_t regs[], int *flagged);
void process_d_instructions(Instruction *inst, int64_t regs[], int8_t memory[],
		int memory_size);
void process_r_instruction(Instruction *inst, int64_t regs[]);
void process_i_instructions(Instruction *inst, int64_t registers[]);
void print_registers(int64_t regs[]);
void print_memory(int8_t memory[], int size);
void print_stack(int8_t stack[], int size);

int main(int argc, char **argv) {
	char input_file[64];
	// Switches for memory and stack size, 0 = false, 1 = true
	int m_switch = 0;
	int s_switch = 0;
	// Default memory and stack sizes
	int memory_size = 4096;
	int stack_size = 512;
	int flag = -1;
	int *flagged = &flag;

	// Process command line arguments
	for (int i = 1; i < argc; i++) {
		if (strcmp(argv[i], "-m") == 0) {
			m_switch = 1; 	// set switch for memory size
			memory_size = atoi(argv[++i]);
		} else if (strcmp(argv[i], "-s") == 0) {
			s_switch = 1;
			stack_size = atoi(argv[++i]);
		} else {
			strcpy(input_file, argv[i]);
		}
	}

	// Check that memory and stack sizes were properly read in
	printf("Memory Size: %d\n", memory_size);
	printf("Stack Size: %d\n", stack_size);

	// Open file
	FILE* fp;
	fp = fopen(input_file, "rb");

	// Check if file is empty
	if (fp == NULL || !fp) {
		fprintf(stderr,
				"Error: Could not open file %s. Please enter a valid file",
				input_file);
		return -1;
	}

	// Find size of the file
	fseek(fp, 0, SEEK_END);
	long file_size = ftell(fp);
	printf("%ld\n", file_size);

	// Reset file pointer to beginning of file
	fseek(fp, 0, SEEK_SET);

	// Initialize arrays for storing binary and parsed instructions
	uint32_t buffer[file_size / 4];
	Instruction instructions[file_size / 4];

	// Array for the registers
	int64_t registers[32];
	int8_t memory[memory_size];
	int8_t stack[stack_size];
	for (int i = 0; i < 32; i++) {
		registers[i] = 0;
	}

	for (int i = 0; i < memory_size; i++) {
		memory[i] = 0;
	}
	for (int i = 0; i < stack_size; i++) {
		stack[i] = 0;
	}
	// Read the instructions into buffer
	fread(buffer, sizeof(buffer), 1, fp);

	// Print the hex values, opcode, and register info of the instructions
	for (int i = 0; i < file_size / 4; i++) {
		buffer[i] = swap_endians(buffer[i]);
		Instruction *iptr = &instructions[i]; // pointer to instruction struct for passing by reference
		parse_instruction(buffer[i], iptr);

		//printf("Opcode: %d\n", instructions[i].opcode);
		//printf("Format: %c\n", instructions[i].format);

		if (instructions[i].format == 'R') {
			printf("%x\n", buffer[i]);
			printf("Opcode: %d\n", instructions[i].opcode);
			printf("Format: %c\n", instructions[i].format);
			printf("Rm: %d\n", instructions[i].data.r.Rm);
			printf("shamt: %d\n", instructions[i].data.r.shamt);
			printf("Rn: %d\n", instructions[i].data.r.Rn);
			printf("Rd: %d\n", instructions[i].data.r.Rd);
		} else if (instructions[i].format == 'I') {
			printf("%x\n", buffer[i]);
			printf("Opcode: %d\n", instructions[i].opcode);
			printf("Format: %c\n", instructions[i].format);
			printf("Immediate: %d\n", instructions[i].data.i.immediate);
			printf("Rn: %d\n", instructions[i].data.i.Rn);
			printf("Rd: %d\n", instructions[i].data.i.Rd);
		} else if (instructions[i].format == 'D') {
			printf("%x\n", buffer[i]);
			printf("Opcode: %d\n", instructions[i].opcode);
			printf("Format: %c\n", instructions[i].format);
			printf("Address: %d\n", instructions[i].data.d.address);
			printf("Rn: %d\n", instructions[i].data.d.Rn);
			printf("Rt: %d\n", instructions[i].data.d.Rt);
		} else if (instructions[i].format == 'B') {
			printf("%x\n", buffer[i]);
			printf("Opcode: %d\n", instructions[i].opcode);
			printf("Format: %c\n", instructions[i].format);
			printf("Address: %d\n", instructions[i].data.b.br_address);
		} else if (instructions[i].format == 'C') {
			printf("%x\n", buffer[i]);
			printf("Opcode: %d\n", instructions[i].opcode);
			printf("Format: %c\n", instructions[i].format);
			printf("Address: %d\n", instructions[i].data.cb.cond_br_address);
			printf("Rt: %d\n", instructions[i].data.cb.Rt);
		}
		printf("\n");

	}

	//registers[1] = 1;
	for (int i = 0; i < file_size / 4; i++) {
		Instruction *iptr = &instructions[i];
		if (iptr->opcode == 1880)
		{
			flag = (int)iptr->data.r.Rd;
		}
		if(iptr->opcode == 1928||iptr->opcode == 1929){
			flag = (int)iptr->data.i.Rd;
		}
		if (instructions[i].format == 'R') {

			process_r_instruction(iptr, registers);
		}

		if (instructions[i].format == 'I') {
			process_i_instructions(iptr, registers);
		}
		if (instructions[i].format == 'D') {
			if (iptr->data.d.Rn == 28)
				process_d_instructions(iptr, registers, stack, stack_size);
			else {
				process_d_instructions(iptr, registers, memory, memory_size);
			}
		}
		if (instructions[i].format == 'B') {
			i = i + instructions[i].data.b.br_address - 1;
		}
		if (instructions[i].format == 'C') {
			if (*flagged == -1) {
				printf("at line %d, there is no flagged register\n", i);
				continue;
			}
			i+=process_c_instruction(iptr, registers, flagged);
		}
	}

	print_registers(registers);
	print_memory(memory, memory_size);
	print_stack(stack, stack_size);

	return 0;
}

void print_registers(int64_t regs[]) {
	for (int i = 0; i < 32; i++) {
		printf("Register %d: %016lx(%d)\n", i, regs[i], regs[i]);
	}
}
void print_memory(int8_t memory[], int size) {
	for (int i = 0; i < size; i++) {
		if (i % 16 == 0) {
			printf("\nmemory %08x:", i);
		}
		printf(" %02hhx(%03d) ", memory[i], memory[i]);
	}
}
void print_stack(int8_t stack[], int size) {
	for (int i = 0; i < size; i++) {

		if (i % 16 == 0) {
			printf("\nstack %08x:", i);
		}
		printf(" %02hhx ", stack[i]);
	}
}

int32_t process_c_instruction(Instruction *inst, int64_t regs[], int *flagged) {
	uint32_t condi = inst->data.cb.Rt;
	int32_t address = inst->data.cb.cond_br_address;
	switch (condi) {
	case 0:
		if (regs[*flagged] == 0) {
			*flagged = -1;
			return address;
		}
		break;		//EQ
	case 1:
		if (regs[*flagged] != 0) {
			*flagged = -1;
			return address;
		}
		break;		//NE
	case 2:
		if (regs[*flagged] >= 0) {
			*flagged = -1;
			return address;
		}
		break; //HS
	case 3:
		if (regs[*flagged] < 0) {
			*flagged = -1;
			return address;
		}
		break; //LO
	case 4:
		if (regs[*flagged] < 0) {
			*flagged = -1;
			return address;
		}
		break; //MI
	case 5:
		if (regs[*flagged] >=0) {
			*flagged = -1;
			return address;
		}
		break; //PL
	case 6:
		*flagged = -1;
		return 0;
		break; //VS
	case 7:
		*flagged = -1;
		return 0;
		break; //VC
	case 8:
		if (regs[*flagged] > 0) {
			*flagged = -1;
			return address;
		}
		break; //HI
	case 9:
		if (regs[*flagged] <= 0) {
			*flagged = -1;
			return address;
		}
		break; //LS
	case 10:
		if (regs[*flagged] >= 0) {
			*flagged = -1;
			return address;
		}
		break; //GE
	case 11:
		if (regs[*flagged] < 0) {
			*flagged = -1;
			return address;
		}
		break; //LT
	case 12:
		if (regs[*flagged] > 0) {
			*flagged = -1;
			return address;
		}
		break; //GT
	case 13:
		if (regs[*flagged] <=0) {
			*flagged = -1;
			return address;
		}
		break; //LE
	default:
		*flagged = -1;
		return 0;
		break;
	}
	*flagged = -1;
	return 0;
}
void process_d_instructions(Instruction *inst, int64_t regs[], int8_t memory[],
		int memory_size) {
	uint32_t offset = inst->data.d.address;
	uint32_t base = inst->data.d.Rn;
	uint32_t target = inst->data.d.Rt;
	if (inst->opcode == 1984)		//STUR
			{
		int64_t temp = regs[target];
		int64_t start = regs[base] + offset;
		for (int i = 0; i < 8; i++) {
			if (start + i >= memory_size) {

			}
		}
		memory[start + 0] = (int8_t) ((temp & 0xff00000000000000) >> 56);
		memory[start + 1] = (int8_t) ((temp & 0x00ff000000000000) >> 48);
		memory[start + 2] = (int8_t) ((temp & 0x0000ff0000000000) >> 40);
		memory[start + 3] = (int8_t) ((temp & 0x000000ff00000000) >> 32);
		memory[start + 4] = (int8_t) ((temp & 0x00000000ff000000) >> 24);
		memory[start + 5] = (int8_t) ((temp & 0x0000000000ff0000) >> 16);
		memory[start + 6] = (int8_t) ((temp & 0x000000000000ff00) >> 8);
		memory[start + 7] = (int8_t) ((temp & 0x00000000000000ff) >> 0);
	} else if (inst->opcode == 1986)		//LDUR
			{
		int64_t start = regs[base] + offset;
		for (int i = 0; i < 8; i++) {
			if (start + i >= memory_size) {

			}
		}
		int64_t temp = ((((int64_t) memory[start + 0] & 0x00000000000000ff))
				<< 56);
		temp = temp
				+ ((((int64_t) memory[start + 1] & 0x00000000000000ff)) << 48);
		temp = temp
				+ ((((int64_t) memory[start + 2] & 0x00000000000000ff)) << 40);
		temp = temp
				+ ((((int64_t) memory[start + 3] & 0x00000000000000ff)) << 32);
		temp = temp
				+ ((((int64_t) memory[start + 4] & 0x00000000000000ff)) << 24);
		temp = temp
				+ ((((int64_t) memory[start + 5] & 0x00000000000000ff)) << 16);
		temp = temp
				+ ((((int64_t) memory[start + 6] & 0x00000000000000ff)) << 8);
		temp = temp
				+ ((((int64_t) memory[start + 7] & 0x00000000000000ff)) << 0);
		regs[target] = temp;
	}
}
void process_r_instruction(Instruction *inst, int64_t regs[]) {
	uint32_t m = inst->data.r.Rm;
	uint32_t shift = inst->data.r.shamt;
	uint32_t n = inst->data.r.Rn;
	uint32_t d = inst->data.r.Rd;

	if (inst->opcode == 1104) {			// AND
		regs[d] = regs[n] & regs[m];
	} else if (inst->opcode == 1112) { 	// ADD
		regs[d] = regs[n] + regs[m];
	} else if (inst->opcode == 1238) {	// UDIV
		regs[d] = regs[n] / regs[m];
		if (regs[d] < 0) {
			regs[d] *= -1;
		}
	} else if (inst->opcode == 1021) {	// PRNT
		printf("X%d: %016x (%d)\n", d, regs[d], regs[d]);
	} else if (inst->opcode == 1240) {	// MUL
		regs[d] = regs[n] * regs[m];

	} else if (inst->opcode == 1360) {	// ORR
		regs[d] = regs[n] | regs[m];
	} else if (inst->opcode == 1616) {	// EOR
		regs[d] = regs[n] ^ regs[m];
	} else if (inst->opcode == 1624) {	// SUB
		regs[d] = regs[n] - regs[m];
	} else if (inst->opcode == 1690) {	// LSR
		regs[d] = regs[n] >> shift;
	} else if (inst->opcode == 1691) {	// LSL
		regs[d] = regs[n] << shift;
	} else if (inst->opcode == 2044) {	// PRNL
		printf("\n");

	}
}

// process instructions of type I given a set of instructions and an array of registers
void process_i_instructions(Instruction *inst, int64_t registers[]) {
	uint32_t rd = inst->data.i.Rd;
	uint32_t rn = inst->data.i.Rn;
	int32_t aluimm = inst->data.i.immediate;

	// ADD Immediate
	if (inst->opcode == 1160 || inst->opcode == 1161) {
		registers[rd] = registers[rn] + (int64_t) aluimm;
	}

	// AND Immediate
	if (inst->opcode == 1168 || inst->opcode == 1169) {
		registers[rd] = registers[rn] & (int64_t) aluimm;
	}

	// EOR Immediate
	if (inst->opcode == 840 || inst->opcode == 841) {
		registers[rd] = registers[rn] ^ (int64_t) aluimm;
	}

	// ORR Immediate
	if (inst->opcode == 1424 || inst->opcode == 1425) {
		registers[rd] = registers[rn] | (int64_t) aluimm;
	}

	// SUB Immediate
	if (inst->opcode == 1672 || inst->opcode == 1673) {
		registers[rd] = registers[rn] - (int64_t) aluimm;
	}
}

void parse_instruction(uint32_t value, Instruction *inst) {
	uint32_t op = get_opcode(value);
	char form = get_format(value);

	if (form == 'R') {
		uint32_t m = (value << (32 - 21)) >> (32 - 5);
		uint32_t shift = (value << (32 - 16)) >> (32 - 6);
		uint32_t n = (value << (32 - 10)) >> (32 - 5);
		uint32_t d = (value << (32 - 5)) >> (32 - 5);

		inst->format = form;
		inst->opcode = op;
		inst->data.r.Rm = m;
		inst->data.r.shamt = shift;
		inst->data.r.Rn = n;
		inst->data.r.Rd = d;
	} else if (form == 'I') {
		int32_t imm = (value << (32 - 22)) >> (32 - 12);
		uint32_t n = (value << (32 - 10)) >> (32 - 5);
		uint32_t d = (value << (32 - 5)) >> (32 - 5);
		if (imm & 0x00000800) {
			imm |= 0xfffff000;
		}
		inst->format = form;
		inst->opcode = op;
		inst->data.i.immediate = imm;
		inst->data.i.Rn = n;
		inst->data.i.Rd = d;
	} else if (form == 'D') {
		uint32_t addr = (value << (32 - 21)) >> (32 - 9);
		uint32_t n = (value << (32 - 10)) >> (32 - 5);
		uint32_t t = (value << (32 - 5)) >> (32 - 5);

		inst->format = form;
		inst->opcode = op;
		inst->data.d.address = addr;
		inst->data.d.Rn = n;
		inst->data.d.Rt = t;
	} else if (form == 'B') {
		int32_t addr = (value << (32 - 26)) >> (32 - 26);
		if (addr & 0x02000000) {
			addr |= 0xfc000000;
		}
		inst->format = form;
		inst->opcode = op;
		inst->data.b.br_address = addr;
	} else if (form == 'C') {
		int32_t addr = (value << (32 - 24)) >> (32 - 19);
		uint32_t t = (value << (32 - 5)) >> (32 - 5);
		if (addr & 0x00040000) {
			addr |= 0xFFF80000;
		}
		inst->format = form;
		inst->opcode = op;
		inst->data.cb.cond_br_address = addr;
		inst->data.cb.Rt = t;
	}
}

uint32_t swap_endians(uint32_t value) {
	uint32_t leftmost_byte;
	uint32_t left_middle_byte;
	uint32_t right_middle_byte;
	uint32_t rightmost_byte;
	uint32_t result;

	leftmost_byte = (value & 0x000000FF) >> 0;
	left_middle_byte = (value & 0x0000FF00) >> 8;
	right_middle_byte = (value & 0x00FF0000) >> 16;
	rightmost_byte = (value & 0xFF000000) >> 24;

	leftmost_byte <<= 24;
	left_middle_byte <<= 16;
	right_middle_byte <<= 8;
	rightmost_byte <<= 0;

	result = (leftmost_byte | left_middle_byte | right_middle_byte
			| rightmost_byte);

	return result;
}

/*
 * Gets a instruction from buffer[] and returns the decimal value of the first 11 bits
 * From the decimal value we can determine the opcode and format of the instruction
 */
uint32_t get_opcode(uint32_t value) {
	uint32_t opcode = value >> (32 - 11);
	return opcode;
}

/*
 * Returns the format of an instruction based off of its opcode
 */
char get_format(uint32_t value) {
	uint32_t opcode = get_opcode(value);
	char format = ' ';

	// B = unconditional branch, C = conditional branch, D = data transfer, I = immediate, R = arithmetic
	if (opcode >= 160 && opcode <= 191) {
		return 'B'; 	// 160-191 = B
	} else if (opcode == 448) {
		return 'D';		// STURB
	} else if (opcode == 450) {
		return 'D';		// LDURB
	} else if (opcode >= 672 && opcode <= 679) {
		return 'C';		// B.cond
	} else if (opcode == 1424 || opcode == 1425) {
		return 'I';		// ORRI
	} else if (opcode == 840 || opcode == 841) {
		return 'I'; 	// EORI
	} else if (opcode == 960) {
		return 'D';		// STURH
	} else if (opcode == 962) {
		return 'D';		// LDURH
	} else if (opcode == 1021) {
		return 'R';		//PRNT

	} else if (opcode == 1104) {
		return 'R';		// AND
	} else if (opcode == 1112) {
		return 'R';		// ADD
	} else if (opcode == 1160 || opcode == 1161) {
		return 'I';		// ADDI
	} else if (opcode == 1168 || opcode == 1169) {
		return 'I';		// ANDI
	} else if (opcode >= 1184 && opcode <= 1215) {
		return 'B';		// BL
	} else if (opcode == 1238) {
		return 'R';		// UDIV
	} else if (opcode == 1240) {
		return 'R';		// MUL

	} else if (opcode == 1360) {
		return 'R';		// ORR
	} else if (opcode >= 1440 && opcode <= 1447) {
		return 'C';		// CBZ
	} else if (opcode >= 1448 && opcode <= 1455) {
		return 'C';		// CBNZ
	} else if (opcode == 1472) {
		return 'D';		// STURW
	} else if (opcode == 1476) {
		return 'D';		// LDURSW
	} else if (opcode == 1616) {
		return 'R';		// EOR
	} else if (opcode == 1624) {
		return 'R';		// SUB
	} else if (opcode == 1672 || opcode == 1673) {
		return 'I';		// SUBI
	} else if (opcode == 1690) {
		return 'R';		// LSR
	} else if (opcode == 1691) {
		return 'R';		// LSL
	} else if (opcode == 1712) {
		return 'R';		// BR
	} else if (opcode == 1880) {
		return 'R';		// SUBS
	} else if (opcode == 1928 || opcode == 1929) {
		return 'I';		// SUBIS
	} else if (opcode == 1984) {
		return 'D';		// STUR
	} else if (opcode == 1986) {
		return 'D';		// LDUR
	} else if (opcode == 2044) {
		return 'R';		// PRNL

	}

	return format;
}
